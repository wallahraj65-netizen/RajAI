import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Square,
  RotateCcw,
  Copy,
  Check,
  Share2,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Plus,
  Search,
  Sparkles,
  Bot,
  User,
  Trash2,
  Languages,
} from 'lucide-react';
import { ChatMessage, Conversation } from '../../types';
import { api } from '../../services/api';

interface ChatScreenProps {
  darkTheme: boolean;
  selectedLanguage: 'English' | 'Hindi' | 'Hinglish';
  onChangeLanguage: (lang: 'English' | 'Hindi' | 'Hinglish') => void;
  conversations: Conversation[];
  activeConversationId: string;
  onSelectConversation: (id: string) => void;
  onNewConversation: () => void;
  onDeleteConversation: (id: string) => void;
  onUpdateConversationMessages: (id: string, messages: ChatMessage[]) => void;
}

export const ChatScreen: React.FC<ChatScreenProps> = ({
  darkTheme,
  selectedLanguage,
  onChangeLanguage,
  conversations,
  activeConversationId,
  onSelectConversation,
  onNewConversation,
  onDeleteConversation,
  onUpdateConversationMessages,
}) => {
  const [inputText, setInputText] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showDrawer, setShowDrawer] = useState(false);

  const abortControllerRef = useRef<AbortController | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const activeConv =
    conversations.find((c) => c.id === activeConversationId) || conversations[0];
  const messages = activeConv?.messages || [];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isGenerating]);

  // Handle Speech-to-Text via Web Speech Recognition API
  const handleToggleVoiceInput = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert('Speech Recognition is not supported in this browser. Please use keyboard input.');
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang =
        selectedLanguage === 'Hindi'
          ? 'hi-IN'
          : selectedLanguage === 'Hinglish'
          ? 'hi-IN'
          : 'en-US';

      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      recognition.onerror = () => setIsListening(false);
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          setInputText((prev) => (prev ? `${prev} ${transcript}` : transcript));
        }
      };

      recognition.start();
    } catch {
      setIsListening(false);
    }
  };

  // Handle Text-to-Speech playback
  const handleSpeak = (text: string, msgId: string) => {
    if (speakingId === msgId) {
      window.speechSynthesis?.cancel();
      setSpeakingId(null);
      return;
    }

    if (!('speechSynthesis' in window)) {
      alert('Speech synthesis is not supported on this device.');
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.lang = selectedLanguage === 'Hindi' ? 'hi-IN' : 'en-US';

    utterance.onend = () => setSpeakingId(null);
    utterance.onerror = () => setSpeakingId(null);

    setSpeakingId(msgId);
    window.speechSynthesis.speak(utterance);
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleShare = (text: string) => {
    if (navigator.share) {
      navigator.share({ title: 'Raj AI Response', text }).catch(() => {});
    } else {
      navigator.clipboard.writeText(text);
      alert('Copied to clipboard for sharing!');
    }
  };

  const handleStopGeneration = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsGenerating(false);
  };

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputText).trim();
    if (!text || isGenerating) return;

    setInputText('');

    const userMessage: ChatMessage = {
      id: `usr_${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: Date.now(),
      language: selectedLanguage,
    };

    const updatedMessages = [...messages, userMessage];
    onUpdateConversationMessages(activeConv.id, updatedMessages);

    setIsGenerating(true);
    abortControllerRef.current = new AbortController();

    const assistantMsgId = `ast_${Date.now()}`;
    const initialAssistantMessage: ChatMessage = {
      id: assistantMsgId,
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
      language: selectedLanguage,
      isStreaming: true,
    };

    let currentMessages = [...updatedMessages, initialAssistantMessage];
    onUpdateConversationMessages(activeConv.id, currentMessages);

    try {
      const response = await api.sendChat(
        updatedMessages.map((m) => ({ role: m.role, content: m.content })),
        selectedLanguage,
        (token: string) => {
          // Streaming callback
          initialAssistantMessage.content += token;
          currentMessages = [
            ...updatedMessages,
            { ...initialAssistantMessage, isStreaming: true },
          ];
          onUpdateConversationMessages(activeConv.id, currentMessages);
        },
        abortControllerRef.current.signal
      );

      // Finalize message
      const finalAssistantMessage: ChatMessage = {
        ...initialAssistantMessage,
        content: response.content || initialAssistantMessage.content,
        isStreaming: false,
        isDemo: response.isDemo,
      };

      onUpdateConversationMessages(activeConv.id, [
        ...updatedMessages,
        finalAssistantMessage,
      ]);
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        const errorMessage: ChatMessage = {
          id: `err_${Date.now()}`,
          role: 'assistant',
          content: `⚠️ Error generating response: ${err.message || 'Please check your connection.'}`,
          timestamp: Date.now(),
          isStreaming: false,
        };
        onUpdateConversationMessages(activeConv.id, [
          ...updatedMessages,
          errorMessage,
        ]);
      }
    } finally {
      setIsGenerating(false);
      abortControllerRef.current = null;
    }
  };

  const handleRegenerate = () => {
    if (messages.length === 0 || isGenerating) return;
    const lastUserIndex = [...messages].reverse().findIndex((m) => m.role === 'user');
    if (lastUserIndex === -1) return;
    const actualIndex = messages.length - 1 - lastUserIndex;
    const lastUserText = messages[actualIndex].content;
    const prunedMessages = messages.slice(0, actualIndex);
    onUpdateConversationMessages(activeConv.id, prunedMessages);
    handleSendMessage(lastUserText);
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden relative">
      {/* Chat Sub-Header Controls */}
      <div
        className={`px-4 py-2 border-b flex items-center justify-between text-xs transition-colors shrink-0 ${
          darkTheme
            ? 'bg-[#0E1528] border-slate-800 text-slate-300'
            : 'bg-slate-50 border-slate-200 text-slate-700'
        }`}
      >
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowDrawer(!showDrawer)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-purple-600/20 hover:bg-purple-600/30 text-purple-400 font-semibold border border-purple-500/20 cursor-pointer"
          >
            <span>Chats ({conversations.length})</span>
          </button>
          <button
            onClick={onNewConversation}
            className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
            title="New Chat"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Language Quick Selector */}
        <div className="flex items-center gap-1">
          <Languages className="w-3.5 h-3.5 text-purple-400" />
          {(['English', 'Hindi', 'Hinglish'] as const).map((lang) => (
            <button
              key={lang}
              onClick={() => onChangeLanguage(lang)}
              className={`px-2 py-0.5 rounded text-[10px] font-semibold transition-colors cursor-pointer ${
                selectedLanguage === lang
                  ? 'bg-purple-600 text-white'
                  : darkTheme
                  ? 'bg-slate-800/80 text-slate-400 hover:text-slate-200'
                  : 'bg-slate-200 text-slate-600 hover:text-slate-900'
              }`}
            >
              {lang === 'English' ? 'EN' : lang === 'Hindi' ? 'HI' : 'Hinglish'}
            </button>
          ))}
        </div>
      </div>

      {/* Conversations Drawer Modal */}
      {showDrawer && (
        <div className="absolute inset-x-0 top-10 bottom-0 z-40 bg-black/60 backdrop-blur-xs flex flex-col p-4 animate-in fade-in duration-150">
          <div
            className={`w-full max-w-sm mx-auto rounded-3xl p-4 flex flex-col max-h-[80%] border shadow-2xl ${
              darkTheme ? 'bg-[#0E1528] border-slate-800' : 'bg-white border-slate-200'
            }`}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-800/50">
              <h3 className="font-bold text-sm">Conversation History</h3>
              <button
                onClick={() => setShowDrawer(false)}
                className="text-xs text-slate-400 hover:text-white"
              >
                ✕ Close
              </button>
            </div>

            <div className="py-2">
              <input
                type="text"
                placeholder="Search conversations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className={`w-full px-3 py-1.5 text-xs rounded-xl border focus:outline-none ${
                  darkTheme
                    ? 'bg-slate-900 border-slate-700 text-white'
                    : 'bg-slate-100 border-slate-300 text-slate-900'
                }`}
              />
            </div>

            <div className="flex-1 overflow-y-auto space-y-1 py-1">
              {conversations
                .filter((c) =>
                  c.title.toLowerCase().includes(searchQuery.toLowerCase())
                )
                .map((conv) => (
                  <div
                    key={conv.id}
                    onClick={() => {
                      onSelectConversation(conv.id);
                      setShowDrawer(false);
                    }}
                    className={`flex items-center justify-between px-3 py-2 rounded-xl text-xs cursor-pointer ${
                      conv.id === activeConv.id
                        ? 'bg-purple-600 text-white font-bold'
                        : darkTheme
                        ? 'hover:bg-slate-800/80 text-slate-300'
                        : 'hover:bg-slate-100 text-slate-700'
                    }`}
                  >
                    <span className="truncate flex-1">{conv.title}</span>
                    {conversations.length > 1 && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteConversation(conv.id);
                        }}
                        className="p-1 hover:text-red-400 opacity-60 hover:opacity-100"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                ))}
            </div>

            <button
              onClick={() => {
                onNewConversation();
                setShowDrawer(false);
              }}
              className="mt-3 w-full py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold flex items-center justify-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Create New Chat</span>
            </button>
          </div>
        </div>
      )}

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center px-4 py-8">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-purple-600 to-cyan-500 p-3 flex items-center justify-center shadow-lg shadow-purple-500/20 mb-4 animate-bounce">
              <Bot className="w-10 h-10 text-white" />
            </div>
            <h3
              className={`text-lg font-bold ${
                darkTheme ? 'text-white' : 'text-slate-900'
              }`}
            >
              Namaste! How can Raj AI assist you?
            </h3>
            <p
              className={`text-xs mt-1 max-w-xs ${
                darkTheme ? 'text-slate-400' : 'text-slate-600'
              }`}
            >
              I understand Hindi, English, and Hinglish. Try these quick starters:
            </p>

            <div className="mt-4 flex flex-col gap-2 w-full max-w-xs text-xs">
              {[
                'Tell me a horror story in Hindi with scene dialogue 👻',
                'Explain Newton\'s laws of motion with real examples 🍎',
                'Write a Kotlin Jetpack Compose ViewModel with StateFlow 📱',
                'Viral BGMI gaming livestream titles and description 🎮',
              ].map((starter, i) => (
                <button
                  key={i}
                  onClick={() => handleSendMessage(starter)}
                  className={`px-3 py-2 rounded-xl text-left border transition-all text-[11px] font-medium cursor-pointer ${
                    darkTheme
                      ? 'bg-slate-900/90 hover:bg-slate-800 border-slate-800 text-slate-300 hover:border-purple-500'
                      : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700 hover:border-purple-400'
                  }`}
                >
                  {starter}
                </button>
              ))}
            </div>
          </div>
        ) : (
          messages.map((message) => {
            const isUser = message.role === 'user';
            return (
              <div
                key={message.id}
                className={`flex gap-2.5 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white shrink-0 mt-0.5 shadow-sm">
                    <Bot className="w-4 h-4" />
                  </div>
                )}

                <div
                  className={`max-w-[85%] rounded-2xl p-3.5 text-xs leading-relaxed shadow-sm transition-all ${
                    isUser
                      ? 'bg-purple-600 text-white rounded-br-xs'
                      : darkTheme
                      ? 'bg-[#131B2E] text-slate-100 border border-slate-800 rounded-bl-xs'
                      : 'bg-white text-slate-900 border border-slate-200 rounded-bl-xs'
                  }`}
                >
                  {/* Bubble Content with line breaks */}
                  <div className="whitespace-pre-wrap break-words font-sans">
                    {message.content}
                    {message.isStreaming && (
                      <span className="inline-block w-1.5 h-3.5 bg-purple-400 ml-1 animate-pulse align-middle" />
                    )}
                  </div>

                  {/* Message Action Bar for Assistant */}
                  {!isUser && !message.isStreaming && message.content && (
                    <div className="mt-2.5 pt-2 border-t border-slate-800/40 flex items-center justify-between text-[10px] text-slate-400">
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleCopy(message.content, message.id)}
                          className="flex items-center gap-1 hover:text-white transition-colors"
                          title="Copy"
                        >
                          {copiedId === message.id ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-400" />
                              <span className="text-emerald-400">Copied</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span>Copy</span>
                            </>
                          )}
                        </button>

                        <button
                          onClick={() => handleSpeak(message.content, message.id)}
                          className="flex items-center gap-1 hover:text-white transition-colors ml-2"
                          title="Listen Voice"
                        >
                          {speakingId === message.id ? (
                            <>
                              <VolumeX className="w-3 h-3 text-purple-400 animate-pulse" />
                              <span className="text-purple-400">Stop</span>
                            </>
                          ) : (
                            <>
                              <Volume2 className="w-3 h-3" />
                              <span>Listen</span>
                            </>
                          )}
                        </button>

                        <button
                          onClick={() => handleShare(message.content)}
                          className="flex items-center gap-1 hover:text-white transition-colors ml-2"
                          title="Share"
                        >
                          <Share2 className="w-3 h-3" />
                          <span>Share</span>
                        </button>
                      </div>

                      {message.isDemo && (
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                          Demo Mode
                        </span>
                      )}
                    </div>
                  )}
                </div>

                {isUser && (
                  <div className="w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center text-slate-300 shrink-0 mt-0.5">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            );
          })
        )}

        {isGenerating && (
          <div className="flex items-center gap-2 text-xs text-purple-400 font-medium pl-10">
            <span className="w-2 h-2 rounded-full bg-purple-400 animate-ping" />
            <span>Raj AI is thinking & typing...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div
        className={`p-3 border-t shrink-0 select-none ${
          darkTheme ? 'bg-[#0A0F1D] border-slate-800' : 'bg-slate-50 border-slate-200'
        }`}
      >
        {isGenerating ? (
          <div className="flex items-center justify-center py-1">
            <button
              onClick={handleStopGeneration}
              className="px-4 py-2 rounded-full bg-red-600 hover:bg-red-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-red-600/30 cursor-pointer animate-pulse"
            >
              <Square className="w-3.5 h-3.5 fill-white" />
              <span>Stop Generating</span>
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            {messages.length > 0 && (
              <button
                onClick={handleRegenerate}
                className={`p-2.5 rounded-2xl border transition-colors cursor-pointer ${
                  darkTheme
                    ? 'bg-slate-900 border-slate-800 hover:bg-slate-800 text-slate-300'
                    : 'bg-white border-slate-200 hover:bg-slate-100 text-slate-700'
                }`}
                title="Regenerate last response"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            )}

            <div
              className={`flex-1 flex items-center rounded-2xl border px-3 py-1.5 transition-all ${
                darkTheme
                  ? 'bg-[#12192D] border-slate-800 focus-within:border-purple-500'
                  : 'bg-white border-slate-200 focus-within:border-purple-500'
              }`}
            >
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                rows={1}
                placeholder={`Ask Raj AI anything in ${selectedLanguage}...`}
                className={`flex-1 bg-transparent text-xs font-medium resize-none focus:outline-none max-h-24 ${
                  darkTheme ? 'text-white placeholder-slate-500' : 'text-slate-900 placeholder-slate-400'
                }`}
              />

              {/* Speech-to-Text Microphone Button */}
              <button
                onClick={handleToggleVoiceInput}
                className={`p-1.5 rounded-full transition-all cursor-pointer ${
                  isListening
                    ? 'bg-red-600 text-white animate-pulse'
                    : darkTheme
                    ? 'text-slate-400 hover:text-purple-400'
                    : 'text-slate-500 hover:text-purple-600'
                }`}
                title={isListening ? 'Listening... Tap to stop' : 'Voice Input (STT)'}
              >
                {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </button>
            </div>

            <button
              onClick={() => handleSendMessage()}
              disabled={!inputText.trim()}
              className={`p-3 rounded-2xl text-white transition-all shadow-md cursor-pointer ${
                inputText.trim()
                  ? 'bg-purple-600 hover:bg-purple-500 shadow-purple-600/30'
                  : 'bg-slate-800 text-slate-500 opacity-60 cursor-not-allowed'
              }`}
              title="Send Message"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
