import React, { useState } from 'react';
import {
  GraduationCap,
  Sparkles,
  HelpCircle,
  CheckCircle2,
  XCircle,
  Lightbulb,
  AlertTriangle,
  BookMarked,
  BrainCircuit,
} from 'lucide-react';
import { StudyOutput } from '../../types';
import { api } from '../../services/api';

interface StudyScreenProps {
  darkTheme: boolean;
  selectedLanguage: 'English' | 'Hindi' | 'Hinglish';
}

export const StudyScreen: React.FC<StudyScreenProps> = ({
  darkTheme,
  selectedLanguage,
}) => {
  const [subject, setSubject] = useState('Science');
  const [topic, setTopic] = useState('Photosynthesis & Cellular Respiration');
  const [mode, setMode] = useState('explain');
  const [studyLang, setStudyLang] = useState<'English' | 'Hindi'>(
    selectedLanguage === 'Hindi' ? 'Hindi' : 'English'
  );
  const [loading, setLoading] = useState(false);
  const [studyData, setStudyData] = useState<StudyOutput | null>(null);

  // Quiz state
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [revealed, setRevealed] = useState<Record<number, boolean>>({});

  const subjects = [
    'Science (Physics/Chem/Bio)',
    'Mathematics',
    'English Grammar & Lit',
    'Social Science & History',
    'Computer Science',
  ];

  const modes = [
    { id: 'explain', label: '📖 Simple Explanation' },
    { id: 'step_by_step_solution', label: '🧮 Step-by-Step Math/Derivation' },
    { id: 'quiz', label: '🎯 Interactive Quiz / MCQs' },
    { id: 'revision_notes', label: '📝 High-Yield Revision Notes' },
  ];

  const handleStudy = async () => {
    if (!topic.trim()) return;
    setLoading(true);
    setSelectedAnswers({});
    setRevealed({});

    try {
      const res = await api.studyAssist({
        subject,
        topic,
        mode,
        language: studyLang,
      });
      setStudyData(res);
    } catch (err: any) {
      alert('Failed to retrieve study material: ' + (err.message || 'Error'));
    } finally {
      setLoading(false);
    }
  };

  const handleSelectOption = (questionIndex: number, optionIndex: number) => {
    setSelectedAnswers((prev) => ({ ...prev, [questionIndex]: optionIndex }));
    setRevealed((prev) => ({ ...prev, [questionIndex]: true }));
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      {/* Header */}
      <div
        className={`p-4 rounded-3xl border shadow-lg ${
          darkTheme
            ? 'bg-gradient-to-r from-emerald-950/40 via-[#13222B] to-[#111A2E] border-emerald-800/30'
            : 'bg-gradient-to-r from-emerald-50 to-teal-50 border-emerald-200'
        }`}
      >
        <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs uppercase tracking-wider">
          <GraduationCap className="w-4 h-4" />
          <span>Academic Tutor & Mentor</span>
        </div>
        <h2 className="text-xl font-black mt-1">AI Study Assistant</h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Master any concept with simple breakdowns, step-by-step logic, and interactive quizzes.
        </p>
      </div>

      {/* Input Form */}
      <div
        className={`p-4 rounded-3xl border space-y-3.5 shadow-md ${
          darkTheme ? 'bg-[#11182B] border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
              Subject
            </label>
            <select
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className={`w-full px-3 py-2 rounded-xl text-xs font-semibold border focus:outline-none ${
                darkTheme
                  ? 'bg-slate-900 border-slate-700 text-white'
                  : 'bg-slate-50 border-slate-300 text-slate-900'
              }`}
            >
              {subjects.map((sub) => (
                <option key={sub} value={sub}>
                  {sub}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
              Language
            </label>
            <select
              value={studyLang}
              onChange={(e) => setStudyLang(e.target.value as any)}
              className={`w-full px-3 py-2 rounded-xl text-xs font-semibold border focus:outline-none ${
                darkTheme
                  ? 'bg-slate-900 border-slate-700 text-white'
                  : 'bg-slate-50 border-slate-300 text-slate-900'
              }`}
            >
              <option value="English">English</option>
              <option value="Hindi">Hindi (हिंदी)</option>
            </select>
          </div>
        </div>

        <div>
          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Question or Topic to Learn
          </label>
          <input
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="e.g. Quadratic Formula, Photosynthesis, French Revolution..."
            className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none ${
              darkTheme
                ? 'bg-slate-900 border-slate-700 text-white'
                : 'bg-slate-50 border-slate-300 text-slate-900'
            }`}
          />
        </div>

        {/* Learning Mode */}
        <div>
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
            Learning Mode
          </label>
          <div className="grid grid-cols-2 gap-1.5">
            {modes.map((m) => (
              <button
                key={m.id}
                onClick={() => setMode(m.id)}
                className={`py-2 px-2.5 rounded-xl text-left text-xs font-medium border transition-all cursor-pointer ${
                  mode === m.id
                    ? 'bg-emerald-600 text-white font-bold border-emerald-500 shadow-md shadow-emerald-600/20'
                    : darkTheme
                    ? 'bg-slate-800/80 hover:bg-slate-700 border-slate-700 text-slate-300'
                    : 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={handleStudy}
          disabled={loading || !topic.trim()}
          className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/30 transition-all cursor-pointer disabled:opacity-60"
        >
          {loading ? (
            <>
              <span className="w-3 h-3 rounded-full border-2 border-white border-t-transparent animate-spin" />
              <span>Analyzing Subject & Formulating Solution...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              <span>Learn & Explain Step-by-Step</span>
            </>
          )}
        </button>
      </div>

      {/* Results Output */}
      {studyData && (
        <div className="space-y-4 pb-8 animate-in fade-in duration-200">
          {/* Summary Box */}
          <div
            className={`p-4 rounded-3xl border shadow-xl ${
              darkTheme ? 'bg-[#131B2E] border-slate-800' : 'bg-white border-slate-200'
            }`}
          >
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 mb-2">
              <BrainCircuit className="w-4 h-4" />
              <span>Core Understanding</span>
            </div>
            <h3 className="text-base font-extrabold text-white">{studyData.title}</h3>
            <p className="mt-2 text-xs text-slate-200 leading-relaxed font-sans">
              {studyData.summary}
            </p>

            {/* Key formulas / points */}
            {studyData.keyFormulasOrPoints?.length > 0 && (
              <div className="mt-3 pt-3 border-t border-slate-800 space-y-1.5">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                  Key Principles & Equations:
                </span>
                {studyData.keyFormulasOrPoints.map((pt, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs text-slate-300">
                    <span className="text-emerald-400 font-bold">•</span>
                    <span>{pt}</span>
                  </div>
                ))}
              </div>
            )}

            {/* Memory Trick */}
            {studyData.memoryTrick && (
              <div className="mt-3 p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-300 flex items-center gap-2">
                <Lightbulb className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  <strong>Memory Hack:</strong> {studyData.memoryTrick}
                </span>
              </div>
            )}
          </div>

          {/* Step by Step Breakdown */}
          {studyData.stepByStep?.length > 0 && (
            <div className="space-y-2.5">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <BookMarked className="w-3.5 h-3.5 text-emerald-400" />
                <span>Step-by-Step Breakdown</span>
              </h4>

              {studyData.stepByStep.map((step) => (
                <div
                  key={step.stepNumber}
                  className={`p-3.5 rounded-2xl border ${
                    darkTheme ? 'bg-[#0E1528] border-slate-800' : 'bg-white border-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-2 font-bold text-xs text-emerald-400">
                    <span className="w-5 h-5 rounded-full bg-emerald-600/30 border border-emerald-500/50 flex items-center justify-center text-[10px]">
                      {step.stepNumber}
                    </span>
                    <span>{step.heading}</span>
                  </div>
                  <p className="mt-1.5 text-xs text-slate-300 pl-7 leading-relaxed">
                    {step.explanation}
                  </p>
                </div>
              ))}
            </div>
          )}

          {/* Interactive Quiz / MCQs */}
          {studyData.quiz?.length > 0 && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <HelpCircle className="w-3.5 h-3.5 text-purple-400" />
                <span>Practice Quiz & Self-Check</span>
              </h4>

              {studyData.quiz.map((q, qIdx) => {
                const isAnswered = revealed[qIdx];
                const selectedOpt = selectedAnswers[qIdx];
                return (
                  <div
                    key={qIdx}
                    className={`p-4 rounded-2xl border ${
                      darkTheme ? 'bg-[#0E1528] border-slate-800' : 'bg-white border-slate-200'
                    }`}
                  >
                    <p className="font-bold text-xs text-white">
                      Q{qIdx + 1}: {q.question}
                    </p>

                    <div className="mt-3 space-y-1.5">
                      {q.options.map((opt, optIdx) => {
                        const isCorrect = optIdx === q.correctIndex;
                        const isUserSelected = selectedOpt === optIdx;

                        let btnStyle = darkTheme
                          ? 'bg-slate-900 border-slate-700 text-slate-200'
                          : 'bg-slate-50 border-slate-200 text-slate-800';

                        if (isAnswered) {
                          if (isCorrect) {
                            btnStyle =
                              'bg-emerald-600/30 border-emerald-500 text-emerald-300 font-bold';
                          } else if (isUserSelected && !isCorrect) {
                            btnStyle = 'bg-red-600/30 border-red-500 text-red-300';
                          }
                        }

                        return (
                          <button
                            key={optIdx}
                            disabled={isAnswered}
                            onClick={() => handleSelectOption(qIdx, optIdx)}
                            className={`w-full text-left p-2.5 rounded-xl text-xs border transition-all flex items-center justify-between cursor-pointer ${btnStyle}`}
                          >
                            <span>{opt}</span>
                            {isAnswered && isCorrect && (
                              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                            )}
                            {isAnswered && isUserSelected && !isCorrect && (
                              <XCircle className="w-4 h-4 text-red-400 shrink-0" />
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {isAnswered && (
                      <div className="mt-2 text-[11px] text-slate-300 bg-slate-900/60 p-2.5 rounded-xl border border-slate-800">
                        <span className="font-bold text-emerald-400">Explanation:</span>{' '}
                        {q.explanation}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* Common Mistakes */}
          {studyData.commonMistakes?.length > 0 && (
            <div className="p-3.5 rounded-2xl bg-amber-950/20 border border-amber-500/30 space-y-1">
              <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Common Traps to Avoid</span>
              </span>
              {studyData.commonMistakes.map((mis, i) => (
                <div key={i} className="text-[11px] text-amber-200/90 pl-5">
                  • {mis}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
