import React, { useState } from 'react';
import {
  Youtube,
  Sparkles,
  Copy,
  Check,
  Flame,
  Gamepad2,
  Image as ImageIcon,
  Clock,
  Tag,
  Hash,
  Video,
} from 'lucide-react';
import { YouTubeOutput } from '../../types';
import { api } from '../../services/api';

interface YouTubeScreenProps {
  darkTheme: boolean;
  selectedLanguage: 'English' | 'Hindi' | 'Hinglish';
}

export const YouTubeScreen: React.FC<YouTubeScreenProps> = ({
  darkTheme,
  selectedLanguage,
}) => {
  const [toolType, setToolType] = useState('bgmi_gaming');
  const [topic, setTopic] = useState('BGMI 1v4 Conqueror Clutch & Secret Gyro Sensitivity');
  const [targetLanguage, setTargetLanguage] = useState<'Hinglish' | 'Hindi' | 'English'>('Hinglish');
  const [loading, setLoading] = useState(false);
  const [ytData, setYtData] = useState<YouTubeOutput | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const subTools = [
    { id: 'bgmi_gaming', label: '🎮 BGMI Gaming & Streams', icon: Gamepad2 },
    { id: 'titles_descriptions', label: '🔥 Viral Titles & SEO Description', icon: Flame },
    { id: 'thumbnails', label: '🖼️ Thumbnail Concepts & Prompts', icon: ImageIcon },
    { id: 'shorts_scripts', label: '📱 Viral Shorts & Reels Script', icon: Video },
  ];

  const handleGenerate = async () => {
    if (!topic.trim()) return;
    setLoading(true);

    try {
      const res = await api.youtubeCreator({
        toolType,
        topic,
        targetLanguage,
      });
      setYtData(res);
    } catch (err: any) {
      alert('Failed to generate YouTube tools: ' + (err.message || 'Error'));
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      {/* Header */}
      <div
        className={`p-4 rounded-3xl border shadow-lg ${
          darkTheme
            ? 'bg-gradient-to-r from-red-950/40 via-[#1C1625] to-[#12172A] border-red-800/30'
            : 'bg-gradient-to-r from-red-50 to-rose-50 border-red-200'
        }`}
      >
        <div className="flex items-center gap-2 text-red-500 font-bold text-xs uppercase tracking-wider">
          <Youtube className="w-4 h-4 fill-red-500" />
          <span>Creator & Gaming Growth Studio</span>
        </div>
        <h2 className="text-xl font-black mt-1">YouTube Creator Hub</h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Viral titles, BGMI stream descriptions, high CTR thumbnail prompts & Shorts hooks.
        </p>
      </div>

      {/* Input */}
      <div
        className={`p-4 rounded-3xl border space-y-3.5 shadow-md ${
          darkTheme ? 'bg-[#11182B] border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        {/* Tool Category Selector */}
        <div>
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
            Creator Tool Focus
          </label>
          <div className="grid grid-cols-2 gap-1.5">
            {subTools.map((st) => (
              <button
                key={st.id}
                onClick={() => setToolType(st.id)}
                className={`py-2 px-2.5 rounded-xl text-left text-xs font-semibold border transition-all cursor-pointer ${
                  toolType === st.id
                    ? 'bg-red-600 text-white font-bold border-red-500 shadow-md shadow-red-600/20'
                    : darkTheme
                    ? 'bg-slate-800/80 hover:bg-slate-700 border-slate-700 text-slate-300'
                    : 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700'
                }`}
              >
                {st.label}
              </button>
            ))}
          </div>
        </div>

        {/* Topic Input */}
        <div>
          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Video Topic / Gameplay Details
          </label>
          <textarea
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            rows={2}
            placeholder="e.g. BGMI Solo vs Squad clutch, Tech review of latest smartphone..."
            className={`w-full px-3 py-2 rounded-2xl text-xs resize-none border focus:outline-none ${
              darkTheme
                ? 'bg-slate-900 border-slate-700 text-white'
                : 'bg-slate-50 border-slate-300 text-slate-900'
            }`}
          />
        </div>

        <div className="flex items-center justify-between">
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            Language Style
          </label>
          <div className="flex items-center gap-1.5">
            {(['Hinglish', 'Hindi', 'English'] as const).map((lang) => (
              <button
                key={lang}
                onClick={() => setTargetLanguage(lang)}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer ${
                  targetLanguage === lang
                    ? 'bg-red-600 text-white'
                    : darkTheme
                    ? 'bg-slate-800 text-slate-400'
                    : 'bg-slate-200 text-slate-700'
                }`}
              >
                {lang}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={handleGenerate}
          disabled={loading || !topic.trim()}
          className="w-full py-3 rounded-2xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-red-600/30 transition-all cursor-pointer disabled:opacity-60"
        >
          {loading ? (
            <>
              <span className="w-3 h-3 rounded-full border-2 border-white border-t-transparent animate-spin" />
              <span>Generating High CTR YouTube Assets...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              <span>Generate Viral YouTube Content</span>
            </>
          )}
        </button>
      </div>

      {/* Results */}
      {ytData && (
        <div className="space-y-4 pb-8 animate-in fade-in duration-200">
          {/* Titles List */}
          {ytData.titles?.length > 0 && (
            <div className="space-y-2.5">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5 text-red-500" />
                <span>Viral High CTR Titles</span>
              </h4>

              {ytData.titles.map((t, i) => (
                <div
                  key={i}
                  className={`p-3.5 rounded-2xl border flex items-center justify-between gap-3 ${
                    darkTheme ? 'bg-[#11182B] border-slate-800' : 'bg-white border-slate-200'
                  }`}
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-red-500/20 text-red-400 border border-red-500/30">
                        Score {t.hookScore}
                      </span>
                      <span className="text-[10px] text-slate-400">{t.reason}</span>
                    </div>
                    <p className="font-bold text-xs mt-1 text-white">{t.title}</p>
                  </div>

                  <button
                    onClick={() => handleCopy(t.title, `title_${i}`)}
                    className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 shrink-0 cursor-pointer"
                    title="Copy Title"
                  >
                    {copiedKey === `title_${i}` ? (
                      <Check className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Description */}
          {ytData.description && (
            <div
              className={`p-4 rounded-3xl border shadow-xl ${
                darkTheme ? 'bg-[#131B2E] border-slate-800' : 'bg-white border-slate-200'
              }`}
            >
              <div className="flex items-center justify-between pb-2 border-b border-slate-800/60">
                <span className="text-xs font-bold text-red-400">
                  SEO Stream & Video Description
                </span>
                <button
                  onClick={() => handleCopy(ytData.description, 'description')}
                  className="flex items-center gap-1 text-[11px] text-red-400 hover:text-white"
                >
                  {copiedKey === 'description' ? (
                    <Check className="w-3 h-3 text-emerald-400" />
                  ) : (
                    <Copy className="w-3 h-3" />
                  )}
                  <span>Copy Description</span>
                </button>
              </div>
              <p className="mt-2 text-xs text-slate-300 whitespace-pre-wrap leading-relaxed font-sans">
                {ytData.description}
              </p>
            </div>
          )}

          {/* Hashtags & Tags */}
          {ytData.hashtags?.length > 0 && (
            <div
              className={`p-3.5 rounded-2xl border ${
                darkTheme ? 'bg-[#11182B] border-slate-800' : 'bg-white border-slate-200'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-400 flex items-center gap-1">
                  <Hash className="w-3.5 h-3.5 text-red-400" />
                  <span>Hashtags</span>
                </span>
                <button
                  onClick={() => handleCopy(ytData.hashtags.join(' '), 'hashtags')}
                  className="text-[11px] text-red-400 hover:text-white"
                >
                  {copiedKey === 'hashtags' ? 'Copied' : 'Copy All'}
                </button>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {ytData.hashtags.map((ht, i) => (
                  <span
                    key={i}
                    className="text-xs font-medium px-2 py-0.5 rounded-lg bg-slate-800 text-red-300 border border-slate-700"
                  >
                    {ht}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Thumbnail Concepts */}
          {ytData.thumbnailConcepts?.length > 0 && (
            <div className="space-y-2.5">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <ImageIcon className="w-3.5 h-3.5 text-red-400" />
                <span>Thumbnail Visual Concept & AI Image Prompt</span>
              </h4>

              {ytData.thumbnailConcepts.map((tc, idx) => (
                <div
                  key={idx}
                  className={`p-4 rounded-2xl border ${
                    darkTheme ? 'bg-[#0E1528] border-slate-800' : 'bg-white border-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-black text-xs text-amber-400 bg-amber-500/20 px-2 py-0.5 rounded-md">
                      Text: "{tc.boldTextOverlay}"
                    </span>
                    <button
                      onClick={() => handleCopy(tc.aiImagePrompt, `thumb_${idx}`)}
                      className="text-[11px] text-red-400 hover:text-white flex items-center gap-1"
                    >
                      {copiedKey === `thumb_${idx}` ? (
                        <Check className="w-3 h-3 text-emerald-400" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                      <span>Copy AI Prompt</span>
                    </button>
                  </div>
                  <p className="mt-2 text-xs text-slate-300">
                    <strong>Visual Scene:</strong> {tc.visualDescription}
                  </p>
                  <p className="mt-2 text-[11px] font-mono text-purple-300 bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                    {tc.aiImagePrompt}
                  </p>
                </div>
              ))}
            </div>
          )}

          {/* Shorts Script */}
          {ytData.shortsScript && (
            <div
              className={`p-4 rounded-3xl border shadow-xl ${
                darkTheme ? 'bg-[#131B2E] border-slate-800' : 'bg-white border-slate-200'
              }`}
            >
              <div className="flex items-center justify-between pb-2 border-b border-slate-800/60">
                <span className="text-xs font-bold text-red-400">
                  Viral Shorts / Reels Script (60s)
                </span>
                <button
                  onClick={() =>
                    handleCopy(
                      `Hook: ${ytData.shortsScript.hook}\n\nBody: ${ytData.shortsScript.retentionBody}\n\nCTA: ${ytData.shortsScript.callToAction}`,
                      'shorts'
                    )
                  }
                  className="flex items-center gap-1 text-[11px] text-red-400 hover:text-white"
                >
                  {copiedKey === 'shorts' ? (
                    <Check className="w-3 h-3 text-emerald-400" />
                  ) : (
                    <Copy className="w-3 h-3" />
                  )}
                  <span>Copy Script</span>
                </button>
              </div>

              <div className="mt-3 space-y-2 text-xs">
                <div className="p-2.5 rounded-xl bg-red-950/30 border border-red-500/30">
                  <span className="font-bold text-red-400 block mb-0.5">
                    🪝 0-3s Stop-The-Scroll Hook:
                  </span>
                  <p className="text-white">{ytData.shortsScript.hook}</p>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="font-bold text-slate-400 block mb-0.5">
                    ⏱️ Retention Value (15-45s):
                  </span>
                  <p className="text-slate-200">{ytData.shortsScript.retentionBody}</p>
                </div>
                <div className="p-2.5 rounded-xl bg-purple-950/30 border border-purple-500/30">
                  <span className="font-bold text-purple-400 block mb-0.5">
                    🔔 Call To Action:
                  </span>
                  <p className="text-white">{ytData.shortsScript.callToAction}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
