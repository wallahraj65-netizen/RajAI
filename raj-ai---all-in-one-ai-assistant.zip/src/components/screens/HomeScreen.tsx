import React, { useState } from 'react';
import {
  MessageSquare,
  BookOpen,
  Image as ImageIcon,
  Video,
  GraduationCap,
  Code2,
  Youtube,
  Volume2,
  Search,
  Sparkles,
  ArrowRight,
  TrendingUp,
  FolderCode,
  Zap,
} from 'lucide-react';
import { NavigationTab } from '../../types';

interface HomeScreenProps {
  onNavigate: (tab: NavigationTab) => void;
  darkTheme: boolean;
  userName?: string;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onNavigate,
  darkTheme,
  userName = 'Raj',
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  // Personalized time greeting
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning ☀️';
    if (hour < 17) return 'Good Afternoon 🌤️';
    return 'Good Evening 🌙';
  };

  const tools = [
    {
      id: 'chat' as NavigationTab,
      title: 'AI Chat',
      hindiTitle: 'एआई चैट',
      subtitle: 'Smart talks in Hindi, English & Hinglish with Voice STT/TTS',
      icon: MessageSquare,
      gradient: 'from-purple-600 to-indigo-600',
      badge: 'Streaming',
      category: 'Core',
    },
    {
      id: 'story' as NavigationTab,
      title: 'AI Story Studio',
      hindiTitle: 'कहानी जनरेटर',
      subtitle: 'Horror, comedy, moral stories with scene scripts & video prompts',
      icon: BookOpen,
      gradient: 'from-amber-500 to-orange-600',
      badge: 'Scene-by-Scene',
      category: 'Creative',
    },
    {
      id: 'image' as NavigationTab,
      title: 'AI Image Studio',
      hindiTitle: 'चित्र जनरेटर',
      subtitle: 'Generate art in 1:1, 16:9, 9:16 with cinematic style presets',
      icon: ImageIcon,
      gradient: 'from-pink-500 to-rose-600',
      badge: 'High-Res',
      category: 'Creative',
    },
    {
      id: 'video_prompts' as NavigationTab,
      title: 'Video Prompts',
      hindiTitle: 'वीडियो प्रॉम्प्ट्स',
      subtitle: 'Direct camera angles, lighting & scripts for Veo, Sora & Runway',
      icon: Video,
      gradient: 'from-cyan-500 to-blue-600',
      badge: 'Cinematic',
      category: 'Creative',
    },
    {
      id: 'study' as NavigationTab,
      title: 'Study Mentor',
      hindiTitle: 'पढ़ाई सहायक',
      subtitle: 'Step-by-step Math & Science solutions, MCQs & revision notes',
      icon: GraduationCap,
      gradient: 'from-emerald-500 to-teal-600',
      badge: 'Step-by-Step',
      category: 'Productivity',
    },
    {
      id: 'code' as NavigationTab,
      title: 'Coding Guru',
      hindiTitle: 'कोडिंग गुरु',
      subtitle: 'Kotlin, Python, Java, JS generator, bug fixer & syntax highlighter',
      icon: Code2,
      gradient: 'from-blue-600 to-indigo-700',
      badge: '7+ Languages',
      category: 'Engineering',
    },
    {
      id: 'youtube' as NavigationTab,
      title: 'YouTube Creator',
      hindiTitle: 'यूट्यूब क्रिएटर',
      subtitle: 'Viral titles, BGMI gaming descriptions, thumbnail concepts & Shorts scripts',
      icon: Youtube,
      gradient: 'from-red-500 to-rose-700',
      badge: 'Viral Hook 99%',
      category: 'Growth',
    },
    {
      id: 'voice_text' as NavigationTab,
      title: 'Voice & Text Tools',
      hindiTitle: 'ध्वनि और अनुवाद',
      subtitle: 'Speech-to-text, audio narration, Hindi translation & grammar fixer',
      icon: Volume2,
      gradient: 'from-violet-600 to-purple-800',
      badge: 'TTS & STT',
      category: 'Linguistic',
    },
    {
      id: 'android_source' as NavigationTab,
      title: 'Android Studio Code',
      hindiTitle: 'एंड्रॉइड सोर्स कोड',
      subtitle: 'Inspect Kotlin, Jetpack Compose, Room & download .ZIP project',
      icon: FolderCode,
      gradient: 'from-emerald-600 to-cyan-600',
      badge: 'Kotlin MVVM',
      category: 'Developer',
    },
  ];

  const filteredTools = tools.filter(
    (t) =>
      t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.subtitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex-1 overflow-y-auto px-4 py-4 space-y-5">
      {/* Personalized Greeting Hero Banner */}
      <div
        className={`relative overflow-hidden rounded-3xl p-5 border shadow-xl ${
          darkTheme
            ? 'bg-gradient-to-br from-purple-950/60 via-[#11162B] to-[#0D1224] border-purple-800/40'
            : 'bg-gradient-to-br from-purple-100 via-indigo-50 to-white border-purple-200'
        }`}
      >
        {/* Decorative background glow */}
        <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-purple-500/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <span
              className={`text-xs font-semibold px-2.5 py-0.5 rounded-full ${
                darkTheme
                  ? 'bg-purple-900/60 text-purple-300 border border-purple-700/50'
                  : 'bg-purple-200/70 text-purple-800'
              }`}
            >
              {getGreeting()}
            </span>
            <div className="flex items-center gap-1 text-[11px] text-purple-400 font-medium">
              <Zap className="w-3.5 h-3.5 fill-purple-400" />
              <span>Fast Response</span>
            </div>
          </div>

          <h2
            className={`text-2xl font-extrabold tracking-tight ${
              darkTheme ? 'text-white' : 'text-slate-900'
            }`}
          >
            Namaste, {userName}! 🙏
          </h2>
          <p
            className={`text-xs leading-relaxed max-w-sm ${
              darkTheme ? 'text-slate-300' : 'text-slate-600'
            }`}
          >
            What would you like to build or explore today with Raj AI?
          </p>

          {/* Quick Action Chips */}
          <div className="mt-2 flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[11px]">
            <button
              onClick={() => onNavigate('chat')}
              className="shrink-0 px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold flex items-center gap-1.5 shadow-md shadow-purple-600/20 cursor-pointer"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Start Chat</span>
            </button>
            <button
              onClick={() => onNavigate('story')}
              className={`shrink-0 px-3 py-1.5 rounded-xl font-medium border cursor-pointer ${
                darkTheme
                  ? 'bg-slate-800/80 hover:bg-slate-700 border-slate-700 text-slate-200'
                  : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800'
              }`}
            >
              📖 Horror Story
            </button>
            <button
              onClick={() => onNavigate('youtube')}
              className={`shrink-0 px-3 py-1.5 rounded-xl font-medium border cursor-pointer ${
                darkTheme
                  ? 'bg-slate-800/80 hover:bg-slate-700 border-slate-700 text-slate-200'
                  : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800'
              }`}
            >
              🎮 BGMI Gaming
            </button>
            <button
              onClick={() => onNavigate('code')}
              className={`shrink-0 px-3 py-1.5 rounded-xl font-medium border cursor-pointer ${
                darkTheme
                  ? 'bg-slate-800/80 hover:bg-slate-700 border-slate-700 text-slate-200'
                  : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800'
              }`}
            >
              💻 Kotlin Code
            </button>
          </div>
        </div>
      </div>

      {/* Search Bar for AI Tools */}
      <div className="relative">
        <Search
          className={`w-4 h-4 absolute left-3.5 top-3.5 ${
            darkTheme ? 'text-slate-400' : 'text-slate-500'
          }`}
        />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search AI features (e.g., Story, Math, BGMI, Python)..."
          className={`w-full pl-10 pr-4 py-2.5 rounded-2xl text-xs font-medium border transition-all focus:outline-none focus:ring-2 focus:ring-purple-500/50 ${
            darkTheme
              ? 'bg-[#11182B] border-slate-800 text-white placeholder-slate-400'
              : 'bg-white border-slate-200 text-slate-900 placeholder-slate-400'
          }`}
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-white"
          >
            ✕
          </button>
        )}
      </div>

      {/* Tools Section Header */}
      <div className="flex items-center justify-between">
        <h3
          className={`text-sm font-bold tracking-tight flex items-center gap-1.5 ${
            darkTheme ? 'text-slate-200' : 'text-slate-800'
          }`}
        >
          <Sparkles className="w-4 h-4 text-purple-400" />
          <span>All AI Capabilities</span>
        </h3>
        <span className="text-[11px] text-slate-400 font-medium">
          {filteredTools.length} modules available
        </span>
      </div>

      {/* Grid of AI Tools */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pb-6">
        {filteredTools.map((tool) => {
          const Icon = tool.icon;
          return (
            <div
              key={tool.id}
              onClick={() => onNavigate(tool.id)}
              className={`group relative p-4 rounded-2xl border transition-all duration-200 cursor-pointer android-ripple ${
                darkTheme
                  ? 'bg-[#11182B]/90 hover:bg-[#162038] border-slate-800/80 hover:border-purple-500/40 shadow-lg'
                  : 'bg-white hover:bg-slate-50 border-slate-200 hover:border-purple-300 shadow-sm'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div
                  className={`w-11 h-11 rounded-xl bg-gradient-to-tr ${tool.gradient} p-2.5 flex items-center justify-center text-white shadow-md shadow-purple-500/20 group-hover:scale-105 transition-transform`}
                >
                  <Icon className="w-6 h-6" />
                </div>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    darkTheme
                      ? 'bg-slate-800 text-purple-300 border border-slate-700'
                      : 'bg-purple-50 text-purple-700 border border-purple-200'
                  }`}
                >
                  {tool.badge}
                </span>
              </div>

              <div className="mt-3">
                <div className="flex items-baseline gap-1.5">
                  <h4
                    className={`text-sm font-bold tracking-tight group-hover:text-purple-400 transition-colors ${
                      darkTheme ? 'text-white' : 'text-slate-900'
                    }`}
                  >
                    {tool.title}
                  </h4>
                  <span className="text-[10px] text-slate-400 font-normal">
                    ({tool.hindiTitle})
                  </span>
                </div>
                <p
                  className={`mt-1 text-[11px] leading-relaxed line-clamp-2 ${
                    darkTheme ? 'text-slate-400' : 'text-slate-600'
                  }`}
                >
                  {tool.subtitle}
                </p>
              </div>

              <div className="mt-3 pt-2.5 border-t border-slate-800/50 flex items-center justify-between text-[11px]">
                <span className="text-slate-400 text-[10px]">{tool.category}</span>
                <span className="flex items-center gap-1 font-semibold text-purple-400 group-hover:translate-x-0.5 transition-transform">
                  <span>Open Tool</span>
                  <ArrowRight className="w-3 h-3" />
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
