import React, { useState } from 'react';
import {
  FolderCode,
  Download,
  Copy,
  Check,
  FileCode,
  FileText,
  Terminal,
  Layers,
  Sparkles,
  ExternalLink,
  ChevronRight,
  ShieldCheck,
} from 'lucide-react';
import { ANDROID_PROJECT_FILES, ProjectFile } from '../../data/androidProjectFiles';
import { downloadAndroidProjectZip } from '../../utils/zipExporter';

interface AndroidSourceScreenProps {
  darkTheme: boolean;
}

export const AndroidSourceScreen: React.FC<AndroidSourceScreenProps> = ({ darkTheme }) => {
  const [selectedFile, setSelectedFile] = useState<ProjectFile>(ANDROID_PROJECT_FILES[7]); // MainActivity.kt by default
  const [copied, setCopied] = useState(false);
  const [downloadingZip, setDownloadingZip] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: 'All Files' },
    { id: 'kotlin', label: 'Kotlin & App' },
    { id: 'compose', label: 'Jetpack Compose' },
    { id: 'database', label: 'Room Database' },
    { id: 'network', label: 'Retrofit & API' },
    { id: 'gradle', label: 'Gradle Config' },
    { id: 'manifest', label: 'Manifest & XML' },
    { id: 'doc', label: 'Docs & Guide' },
  ];

  const filteredFiles =
    selectedCategory === 'all'
      ? ANDROID_PROJECT_FILES
      : ANDROID_PROJECT_FILES.filter((f) => f.category === selectedCategory);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setDownloadingZip(true);
    try {
      await downloadAndroidProjectZip();
    } catch (e: any) {
      alert('Failed to generate ZIP: ' + e.message);
    } finally {
      setDownloadingZip(false);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      {/* Header Banner */}
      <div
        className={`p-4 rounded-3xl border shadow-lg ${
          darkTheme
            ? 'bg-gradient-to-r from-emerald-950/40 via-[#13232C] to-[#111A2E] border-emerald-800/30'
            : 'bg-gradient-to-r from-emerald-50 to-cyan-50 border-emerald-200'
        }`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs uppercase tracking-wider">
            <FolderCode className="w-4 h-4" />
            <span>Android Studio Project Exporter</span>
          </div>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30">
            API 26-35 Ready
          </span>
        </div>

        <h2 className="text-xl font-black mt-1">Full Android Source Code</h2>
        <p className="text-xs text-slate-300 mt-0.5">
          Production Kotlin, Jetpack Compose, Room Database, and Retrofit architecture.
        </p>

        {/* Big 1-Click ZIP Download Button */}
        <button
          onClick={handleDownloadZip}
          disabled={downloadingZip}
          className="mt-3 w-full py-2.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/30 transition-all cursor-pointer disabled:opacity-50"
        >
          {downloadingZip ? (
            <>
              <span className="w-3.5 h-3.5 rounded-full border-2 border-white border-t-transparent animate-spin" />
              <span>Packaging Android Studio Project (.ZIP)...</span>
            </>
          ) : (
            <>
              <Download className="w-4 h-4" />
              <span>Download Complete Android Studio Project (.ZIP)</span>
            </>
          )}
        </button>
      </div>

      {/* Category Filter Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
        {categories.map((c) => (
          <button
            key={c.id}
            onClick={() => setSelectedCategory(c.id)}
            className={`shrink-0 px-2.5 py-1 rounded-xl text-[11px] font-semibold transition-all cursor-pointer ${
              selectedCategory === c.id
                ? 'bg-emerald-600 text-white'
                : darkTheme
                ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
            }`}
          >
            {c.label}
          </button>
        ))}
      </div>

      {/* Two-part layout: File List & Code Viewer */}
      <div className="space-y-3">
        {/* File Selector Dropdown / Cards */}
        <div>
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Select Project File ({filteredFiles.length} files)
          </label>
          <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto p-1.5 rounded-2xl bg-slate-900/60 border border-slate-800">
            {filteredFiles.map((file) => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`px-2 py-1 rounded-lg text-[10px] font-mono transition-all truncate max-w-[200px] cursor-pointer ${
                    isSelected
                      ? 'bg-emerald-600 text-white font-bold shadow-xs'
                      : darkTheme
                      ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      : 'bg-white text-slate-700 hover:bg-slate-100 border'
                  }`}
                  title={file.path}
                >
                  {file.path.split('/').pop()}
                </button>
              );
            })}
          </div>
        </div>

        {/* Code Viewer Card */}
        <div
          className={`rounded-3xl border shadow-xl overflow-hidden ${
            darkTheme ? 'bg-[#0B0F1D] border-slate-800' : 'bg-slate-900 border-slate-800 text-white'
          }`}
        >
          {/* File Header */}
          <div className="px-4 py-2.5 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2 min-w-0">
              <FileCode className="w-4 h-4 text-emerald-400 shrink-0" />
              <div className="truncate">
                <span className="text-xs font-mono font-bold text-emerald-300 truncate">
                  {selectedFile.path}
                </span>
                <p className="text-[10px] text-slate-400 truncate">
                  {selectedFile.description}
                </p>
              </div>
            </div>

            <button
              onClick={handleCopyCode}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-300 border border-emerald-500/30 text-xs font-semibold cursor-pointer shrink-0 ml-2"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy File</span>
                </>
              )}
            </button>
          </div>

          {/* Code Text */}
          <div className="p-4 overflow-x-auto text-[11px] font-mono leading-relaxed bg-slate-950 text-slate-100 max-h-96">
            <pre>
              <code>{selectedFile.content}</code>
            </pre>
          </div>
        </div>

        {/* Build & APK Instructions Card */}
        <div
          className={`p-4 rounded-3xl border space-y-2.5 ${
            darkTheme ? 'bg-[#11182B] border-slate-800' : 'bg-white border-slate-200'
          }`}
        >
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
            <Terminal className="w-4 h-4" />
            <span>How to Build APK in Android Studio</span>
          </div>

          <div className="space-y-2 text-xs text-slate-300">
            <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[11px]">
              <span className="text-slate-500"># 1. Download & Extract ZIP</span>
              <br />
              <span className="text-emerald-400">unzip</span> RajAI-AndroidStudio-Project.zip
              <br />
              <span className="text-slate-500"># 2. Build Debug APK directly with Gradle</span>
              <br />
              ./gradlew <span className="text-cyan-400">assembleDebug</span>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed">
              Once built, the APK will be available in{' '}
              <code className="text-purple-300 bg-slate-900 px-1 py-0.5 rounded">
                app/build/outputs/apk/debug/app-debug.apk
              </code>
              . You can install it on your Android phone using{' '}
              <code className="text-purple-300 bg-slate-900 px-1 py-0.5 rounded">
                adb install app-debug.apk
              </code>
              .
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
