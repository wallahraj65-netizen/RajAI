import React, { useState, useEffect } from 'react';
import {
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  Sparkles,
  Copy,
  Check,
  Languages,
  FileText,
  SpellCheck,
  RefreshCw,
  Sliders,
  Play,
  RotateCcw,
} from 'lucide-react';
import { TextToolsOutput } from '../../types';
import { api } from '../../services/api';

interface VoiceTextScreenProps {
  darkTheme: boolean;
  selectedLanguage: 'English' | 'Hindi' | 'Hinglish';
}

export const VoiceTextScreen: React.FC<VoiceTextScreenProps> = ({
  darkTheme,
  selectedLanguage,
}) => {
  const [action, setAction] = useState('summarize');
  const [text, setText] = useState(
    'Raj AI is a state-of-the-art intelligent assistant built with Jetpack Compose and Kotlin. It combines speech recognition, real-time voice synthesis, and multi-lingual reasoning in Hindi, English, and Hinglish.'
  );
  const [targetLang, setTargetLang] = useState('Hindi');
  const [tone, setTone] = useState('Professional');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<TextToolsOutput | null>(null);
  const [copied, setCopied] = useState(false);

  // Audio / TTS state
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoiceIndex, setSelectedVoiceIndex] = useState(0);
  const [speechRate, setSpeechRate] = useState(1.0);
  const [speechPitch, setSpeechPitch] = useState(1.0);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [isListening, setIsListening] = useState(false);

  useEffect(() => {
    const loadVoices = () => {
      if ('speechSynthesis' in window) {
        const vList = window.speechSynthesis.getVoices();
        setVoices(vList);
      }
    };
    loadVoices();
    if ('speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }
  }, []);

  const handleProcessText = async () => {
    if (!text.trim()) return;
    setLoading(true);

    try {
      const res = await api.textTools({
        action,
        text,
        targetLanguage: targetLang,
        tone,
      });
      setResult(res);
    } catch (err: any) {
      alert('Failed to process text: ' + (err.message || 'Error'));
    } finally {
      setLoading(false);
    }
  };

  const handleSpeak = (textToSpeak: string) => {
    if (!('speechSynthesis' in window)) {
      alert('Speech synthesis not supported on this device.');
      return;
    }

    if (isPlayingAudio) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    if (voices[selectedVoiceIndex]) {
      utterance.voice = voices[selectedVoiceIndex];
    }
    utterance.rate = speechRate;
    utterance.pitch = speechPitch;

    utterance.onend = () => setIsPlayingAudio(false);
    utterance.onerror = () => setIsPlayingAudio(false);

    setIsPlayingAudio(true);
    window.speechSynthesis.speak(utterance);
  };

  const handleSpeechToText = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert('Speech Recognition is not supported on this browser.');
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    try {
      const rec = new SpeechRecognition();
      rec.continuous = false;
      rec.lang = targetLang === 'Hindi' ? 'hi-IN' : 'en-US';
      rec.onstart = () => setIsListening(true);
      rec.onend = () => setIsListening(false);
      rec.onerror = () => setIsListening(false);
      rec.onresult = (ev: any) => {
        const transcript = ev.results[0][0].transcript;
        if (transcript) {
          setText((prev) => (prev ? `${prev} ${transcript}` : transcript));
        }
      };
      rec.start();
    } catch {
      setIsListening(false);
    }
  };

  const handleCopyResult = () => {
    if (!result) return;
    navigator.clipboard.writeText(result.result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const actions = [
    { id: 'summarize', label: '📄 Summarize', icon: FileText },
    { id: 'translate', label: '🌐 Translate', icon: Languages },
    { id: 'grammar', label: '✍️ Fix Grammar', icon: SpellCheck },
    { id: 'rewrite', label: '🔄 Tone Rewrite', icon: RefreshCw },
  ];

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      {/* Header */}
      <div
        className={`p-4 rounded-3xl border shadow-lg ${
          darkTheme
            ? 'bg-gradient-to-r from-violet-950/40 via-[#19152B] to-[#12172A] border-violet-800/30'
            : 'bg-gradient-to-r from-violet-50 to-purple-50 border-violet-200'
        }`}
      >
        <div className="flex items-center gap-2 text-violet-400 font-bold text-xs uppercase tracking-wider">
          <Volume2 className="w-4 h-4" />
          <span>Speech, Voice & Linguistic Engine</span>
        </div>
        <h2 className="text-xl font-black mt-1">AI Voice & Text Tools</h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Speech synthesis, voice-to-text, translation, summarization, and tone rewriting.
        </p>
      </div>

      {/* Mode Buttons */}
      <div className="grid grid-cols-2 gap-2">
        {actions.map((act) => (
          <button
            key={act.id}
            onClick={() => setAction(act.id)}
            className={`p-2.5 rounded-2xl text-xs font-bold border transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              action === act.id
                ? 'bg-violet-600 text-white border-violet-500 shadow-md shadow-violet-600/20'
                : darkTheme
                ? 'bg-[#11182B] border-slate-800 text-slate-300 hover:bg-slate-800'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <span>{act.label}</span>
          </button>
        ))}
      </div>

      {/* Main Input Box */}
      <div
        className={`p-4 rounded-3xl border space-y-3.5 shadow-md ${
          darkTheme ? 'bg-[#11182B] border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex items-center justify-between">
          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            Input Text / Dictation
          </label>
          <div className="flex items-center gap-2">
            <button
              onClick={handleSpeechToText}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold cursor-pointer ${
                isListening
                  ? 'bg-red-600 text-white animate-pulse'
                  : 'bg-purple-600/20 text-purple-400 hover:bg-purple-600/30'
              }`}
            >
              {isListening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
              <span>{isListening ? 'Listening...' : 'Voice Input (STT)'}</span>
            </button>
          </div>
        </div>

        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={3}
          placeholder="Enter or dictate text to process..."
          className={`w-full px-3 py-2.5 rounded-2xl text-xs resize-none border focus:outline-none leading-relaxed ${
            darkTheme
              ? 'bg-slate-900 border-slate-700 text-white'
              : 'bg-slate-50 border-slate-300 text-slate-900'
          }`}
        />

        {/* Translation or Rewrite Options */}
        {action === 'translate' && (
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
              Translate To Language
            </label>
            <select
              value={targetLang}
              onChange={(e) => setTargetLang(e.target.value)}
              className={`w-full px-3 py-2 rounded-xl text-xs font-semibold border focus:outline-none ${
                darkTheme
                  ? 'bg-slate-900 border-slate-700 text-white'
                  : 'bg-slate-50 border-slate-300 text-slate-900'
              }`}
            >
              <option value="Hindi">Hindi (हिंदी)</option>
              <option value="English">English</option>
              <option value="Hinglish">Hinglish</option>
              <option value="Bengali">Bengali (বাংলা)</option>
              <option value="Telugu">Telugu (తెలుగు)</option>
              <option value="Marathi">Marathi (मराठी)</option>
              <option value="Tamil">Tamil (தமிழ்)</option>
            </select>
          </div>
        )}

        {action === 'rewrite' && (
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
              Select Tone
            </label>
            <select
              value={tone}
              onChange={(e) => setTone(e.target.value)}
              className={`w-full px-3 py-2 rounded-xl text-xs font-semibold border focus:outline-none ${
                darkTheme
                  ? 'bg-slate-900 border-slate-700 text-white'
                  : 'bg-slate-50 border-slate-300 text-slate-900'
              }`}
            >
              <option value="Professional & Formal">Professional & Formal</option>
              <option value="Casual & Friendly">Casual & Friendly</option>
              <option value="Persuasive & Engaging">Persuasive & Engaging</option>
              <option value="Ultra Concise">Ultra Concise</option>
            </select>
          </div>
        )}

        {/* Text-to-Speech Voice Controls */}
        <div className="pt-2 border-t border-slate-800/60 space-y-2">
          <div className="flex items-center justify-between text-[11px] font-bold text-slate-400">
            <span className="flex items-center gap-1">
              <Sliders className="w-3.5 h-3.5 text-violet-400" />
              <span>Voice Synthesis Settings</span>
            </span>
            <button
              onClick={() => handleSpeak(text)}
              className="flex items-center gap-1 text-violet-400 hover:text-white font-semibold cursor-pointer"
            >
              {isPlayingAudio ? (
                <>
                  <VolumeX className="w-3.5 h-3.5 text-red-400" />
                  <span className="text-red-400">Stop Speech</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>Speak Input Text (TTS)</span>
                </>
              )}
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[11px]">
            <div>
              <span className="text-[10px] text-slate-500 block mb-0.5">
                Speech Speed ({speechRate}x)
              </span>
              <input
                type="range"
                min="0.5"
                max="2.0"
                step="0.1"
                value={speechRate}
                onChange={(e) => setSpeechRate(parseFloat(e.target.value))}
                className="w-full accent-violet-500"
              />
            </div>
            <div>
              <span className="text-[10px] text-slate-500 block mb-0.5">
                Pitch ({speechPitch}x)
              </span>
              <input
                type="range"
                min="0.5"
                max="1.5"
                step="0.1"
                value={speechPitch}
                onChange={(e) => setSpeechPitch(parseFloat(e.target.value))}
                className="w-full accent-violet-500"
              />
            </div>
          </div>
        </div>

        <button
          onClick={handleProcessText}
          disabled={loading || !text.trim()}
          className="w-full py-3 rounded-2xl bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-violet-600/30 transition-all cursor-pointer disabled:opacity-60"
        >
          {loading ? (
            <>
              <span className="w-3 h-3 rounded-full border-2 border-white border-t-transparent animate-spin" />
              <span>Processing Linguistic Engine...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              <span>Process Text ({action.toUpperCase()})</span>
            </>
          )}
        </button>
      </div>

      {/* Output Card */}
      {result && (
        <div
          className={`p-4 rounded-3xl border shadow-xl space-y-3 animate-in fade-in duration-200 ${
            darkTheme ? 'bg-[#131B2E] border-slate-800' : 'bg-white border-slate-200'
          }`}
        >
          <div className="flex items-center justify-between pb-2 border-b border-slate-800/60">
            <span className="text-xs font-bold text-violet-400 capitalize">
              {result.action} Result
            </span>

            <div className="flex items-center gap-2">
              <button
                onClick={() => handleSpeak(result.result)}
                className="flex items-center gap-1 text-[11px] font-semibold text-violet-400 hover:text-white"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>Read Out Loud</span>
              </button>
              <button
                onClick={handleCopyResult}
                className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                title="Copy Result"
              >
                {copied ? (
                  <Check className="w-4 h-4 text-emerald-400" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </button>
            </div>
          </div>

          <p className="text-xs leading-relaxed text-white whitespace-pre-wrap font-sans">
            {result.result}
          </p>

          {/* Stats Bar */}
          {result.stats && (
            <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between text-[10px] text-slate-400">
              <span>Original Words: {result.stats.originalWordCount}</span>
              <span>Refined Words: {result.stats.processedWordCount}</span>
              <span>Read Time: ~{result.stats.readingTimeSeconds}s</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
