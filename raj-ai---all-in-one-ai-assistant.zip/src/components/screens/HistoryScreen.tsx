import React, { useState } from 'react';
import {
  Clock,
  Trash2,
  Download,
  Search,
  MessageSquare,
  Sparkles,
  Shield,
  FileJson,
  ArrowRight,
  Database,
} from 'lucide-react';
import { Conversation, NavigationTab } from '../../types';

interface HistoryScreenProps {
  darkTheme: boolean;
  conversations: Conversation[];
  onSelectConversation: (id: string) => void;
  onDeleteConversation: (id: string) => void;
  onClearAllHistory: () => void;
  onNavigate: (tab: NavigationTab) => void;
}

export const HistoryScreen: React.FC<HistoryScreenProps> = ({
  darkTheme,
  conversations,
  onSelectConversation,
  onDeleteConversation,
  onClearAllHistory,
  onNavigate,
}) => {
  const [search, setSearch] = useState('');

  const filtered = conversations.filter(
    (c) =>
      c.title.toLowerCase().includes(search.toLowerCase()) ||
      c.messages.some((m) => m.content.toLowerCase().includes(search.toLowerCase()))
  );

  const handleExportJson = () => {
    const dataStr = JSON.stringify(conversations, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `RajAI-History-Backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      {/* Header */}
      <div
        className={`p-4 rounded-3xl border shadow-lg ${
          darkTheme
            ? 'bg-gradient-to-r from-slate-900 via-[#141B2D] to-[#101626] border-slate-800'
            : 'bg-gradient-to-r from-slate-100 to-indigo-50 border-slate-200'
        }`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-purple-400 font-bold text-xs uppercase tracking-wider">
            <Database className="w-4 h-4" />
            <span>Room Database Persistence</span>
          </div>

          <button
            onClick={handleExportJson}
            className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 text-purple-400 text-xs font-semibold border border-purple-500/20 cursor-pointer"
            title="Export all data to JSON"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export JSON</span>
          </button>
        </div>

        <h2 className="text-xl font-black mt-1">Local History</h2>
        <p className="text-xs text-slate-400 mt-0.5">
          All your chats and creations are stored on this device. Zero cloud tracking.
        </p>
      </div>

      {/* Search & Actions Bar */}
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search saved conversations..."
            className={`w-full pl-9 pr-3 py-2 text-xs rounded-2xl border focus:outline-none ${
              darkTheme
                ? 'bg-slate-900 border-slate-800 text-white'
                : 'bg-white border-slate-200 text-slate-900'
            }`}
          />
        </div>

        {conversations.length > 0 && (
          <button
            onClick={() => {
              if (confirm('Are you sure you want to clear all history?')) {
                onClearAllHistory();
              }
            }}
            className="p-2 rounded-2xl bg-red-600/20 hover:bg-red-600/30 text-red-400 border border-red-500/30 text-xs font-semibold flex items-center gap-1 cursor-pointer"
            title="Clear All History"
          >
            <Trash2 className="w-4 h-4" />
            <span className="hidden sm:inline">Clear All</span>
          </button>
        )}
      </div>

      {/* History Items List */}
      <div className="space-y-2.5 pb-6">
        {filtered.length === 0 ? (
          <div className="p-8 text-center flex flex-col items-center justify-center">
            <Clock className="w-10 h-10 text-slate-600 mb-2" />
            <h4 className="text-sm font-bold text-slate-400">No History Records Found</h4>
            <p className="text-xs text-slate-500 mt-1 max-w-xs">
              Conversations and creations will automatically appear here when you interact with Raj AI.
            </p>
            <button
              onClick={() => onNavigate('chat')}
              className="mt-4 px-4 py-2 rounded-xl bg-purple-600 text-white text-xs font-bold shadow-md shadow-purple-600/30 cursor-pointer"
            >
              Start New Chat
            </button>
          </div>
        ) : (
          filtered.map((conv) => {
            const dateStr = new Date(conv.updatedAt).toLocaleDateString([], {
              month: 'short',
              day: 'numeric',
              hour: '2-digit',
              minute: '2-digit',
            });
            const lastMsg = conv.messages[conv.messages.length - 1]?.content || 'Empty chat';

            return (
              <div
                key={conv.id}
                onClick={() => {
                  onSelectConversation(conv.id);
                  onNavigate('chat');
                }}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                  darkTheme
                    ? 'bg-[#11182B] hover:bg-[#162038] border-slate-800'
                    : 'bg-white hover:bg-slate-50 border-slate-200'
                }`}
              >
                <div className="flex items-start gap-3 flex-1 min-w-0">
                  <div className="w-9 h-9 rounded-xl bg-purple-600/20 text-purple-400 flex items-center justify-center shrink-0 mt-0.5">
                    <MessageSquare className="w-4 h-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold text-white truncate max-w-[200px]">
                        {conv.title}
                      </h4>
                      <span className="text-[10px] text-slate-500">{dateStr}</span>
                    </div>
                    <p className="text-[11px] text-slate-400 truncate mt-0.5">{lastMsg}</p>
                    <div className="mt-1 flex items-center gap-2 text-[10px] text-slate-500">
                      <span>{conv.messages.length} messages</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteConversation(conv.id);
                    }}
                    className="p-1.5 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-500/10 cursor-pointer"
                    title="Delete Conversation"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                  <ArrowRight className="w-3.5 h-3.5 text-slate-600" />
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Privacy Guarantee Note */}
      <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800/80 flex items-start gap-2.5 text-[11px] text-slate-400">
        <Shield className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
        <p>
          <strong>Data Privacy:</strong> All conversation threads and generated scripts are cached on your client device using standard Room/LocalStorage mechanics. You can export or purge history at any time.
        </p>
      </div>
    </div>
  );
};
