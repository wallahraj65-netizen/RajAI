import React, { useState } from 'react';
import {
  Code2,
  Sparkles,
  Copy,
  Check,
  Bug,
  Terminal,
  Play,
  Cpu,
  Layers,
} from 'lucide-react';
import { CodeOutput } from '../../types';
import { api } from '../../services/api';

interface CodeScreenProps {
  darkTheme: boolean;
}

export const CodeScreen: React.FC<CodeScreenProps> = ({ darkTheme }) => {
  const [language, setLanguage] = useState('Kotlin');
  const [task, setTask] = useState('generate');
  const [query, setQuery] = useState(
    'Create an Android Jetpack Compose bottom navigation bar with badging and animated pill'
  );
  const [codeSnippet, setCodeSnippet] = useState('');
  const [loading, setLoading] = useState(false);
  const [codeResult, setCodeResult] = useState<CodeOutput | null>(null);
  const [copied, setCopied] = useState(false);

  const languages = ['Kotlin', 'Python', 'Java', 'JavaScript', 'HTML/CSS', 'SQL'];

  const tasks = [
    { id: 'generate', label: '⚡ Generate Code' },
    { id: 'debug', label: '🐛 Debug & Fix Error' },
    { id: 'explain', label: '🔍 Explain Logic' },
    { id: 'optimize', label: '🚀 Optimize Performance' },
  ];

  const handleRunCode = async () => {
    if (!query.trim() && !codeSnippet.trim()) return;
    setLoading(true);

    try {
      const res = await api.codeAssist({
        language,
        task,
        query,
        codeSnippet,
      });
      setCodeResult(res);
    } catch (err: any) {
      alert('Coding assistant failed: ' + (err.message || 'Error'));
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!codeResult) return;
    navigator.clipboard.writeText(codeResult.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      {/* Header */}
      <div
        className={`p-4 rounded-3xl border shadow-lg ${
          darkTheme
            ? 'bg-gradient-to-r from-blue-950/40 via-[#151F38] to-[#111A2E] border-blue-800/30'
            : 'bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200'
        }`}
      >
        <div className="flex items-center gap-2 text-blue-400 font-bold text-xs uppercase tracking-wider">
          <Code2 className="w-4 h-4" />
          <span>Full-Stack & Android Engineering</span>
        </div>
        <h2 className="text-xl font-black mt-1">AI Coding Guru</h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Write, debug, and optimize Kotlin, Python, Java, JS, HTML & SQL with line-by-line breakdown.
        </p>
      </div>

      {/* Input Box */}
      <div
        className={`p-4 rounded-3xl border space-y-3.5 shadow-md ${
          darkTheme ? 'bg-[#11182B] border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        {/* Language selector chips */}
        <div>
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
            Programming Language
          </label>
          <div className="flex flex-wrap gap-1.5">
            {languages.map((lang) => (
              <button
                key={lang}
                onClick={() => setLanguage(lang)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  language === lang
                    ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/20'
                    : darkTheme
                    ? 'bg-slate-800/80 hover:bg-slate-700 text-slate-300'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {lang}
              </button>
            ))}
          </div>
        </div>

        {/* Task type */}
        <div>
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
            Task Objective
          </label>
          <div className="grid grid-cols-2 gap-1.5">
            {tasks.map((t) => (
              <button
                key={t.id}
                onClick={() => setTask(t.id)}
                className={`py-1.5 px-2.5 rounded-xl text-xs text-left font-medium border transition-all cursor-pointer ${
                  task === t.id
                    ? 'bg-blue-600/30 border-blue-500 text-blue-300 font-bold'
                    : darkTheme
                    ? 'bg-slate-800/80 border-slate-700 text-slate-300'
                    : 'bg-slate-100 border-slate-200 text-slate-700'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        {/* Query */}
        <div>
          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Requirement or Question
          </label>
          <textarea
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            rows={2}
            placeholder="What code do you want to generate or problem to solve?"
            className={`w-full px-3 py-2 rounded-2xl text-xs resize-none border focus:outline-none ${
              darkTheme
                ? 'bg-slate-900 border-slate-700 text-white'
                : 'bg-slate-50 border-slate-300 text-slate-900'
            }`}
          />
        </div>

        {/* Optional code snippet to debug */}
        {(task === 'debug' || task === 'explain' || task === 'optimize') && (
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1 flex items-center justify-between">
              <span>Existing Code / Stack Trace</span>
              <span className="text-[9px] text-slate-500">Optional</span>
            </label>
            <textarea
              value={codeSnippet}
              onChange={(e) => setCodeSnippet(e.target.value)}
              rows={3}
              placeholder="Paste code or error log here..."
              className="w-full px-3 py-2 rounded-xl text-xs font-mono resize-none border focus:outline-none bg-slate-950 text-slate-200 border-slate-800"
            />
          </div>
        )}

        <button
          onClick={handleRunCode}
          disabled={loading || (!query.trim() && !codeSnippet.trim())}
          className="w-full py-3 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-blue-600/30 transition-all cursor-pointer disabled:opacity-60"
        >
          {loading ? (
            <>
              <span className="w-3 h-3 rounded-full border-2 border-white border-t-transparent animate-spin" />
              <span>Analyzing Syntax, Architecture & Logic...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              <span>Generate / Debug {language} Code</span>
            </>
          )}
        </button>
      </div>

      {/* Code Result */}
      {codeResult && (
        <div className="space-y-4 pb-8 animate-in fade-in duration-200">
          <div
            className={`rounded-3xl border shadow-xl overflow-hidden ${
              darkTheme ? 'bg-[#0F172A] border-slate-800' : 'bg-slate-900 border-slate-800 text-white'
            }`}
          >
            {/* Editor Top Bar */}
            <div className="px-4 py-2.5 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="flex gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
                  <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/80" />
                  <div className="w-2.5 h-2.5 rounded-full bg-green-500/80" />
                </div>
                <span className="text-xs font-bold text-blue-400 ml-1">
                  {codeResult.title || `${language} Solution`}
                </span>
              </div>

              <button
                onClick={handleCopy}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-600/30 hover:bg-blue-600/50 text-blue-300 border border-blue-500/30 text-xs font-semibold transition-all cursor-pointer"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Code</span>
                  </>
                )}
              </button>
            </div>

            {/* Code Body */}
            <div className="p-4 overflow-x-auto text-xs font-mono leading-relaxed bg-slate-950 text-slate-100">
              <pre>
                <code>{codeResult.code}</code>
              </pre>
            </div>

            {/* Complexity Badges */}
            <div className="px-4 py-2.5 bg-slate-900 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-300">
              <div className="flex items-center gap-3">
                <span>
                  <strong>Time:</strong>{' '}
                  <span className="text-emerald-400">{codeResult.timeComplexity}</span>
                </span>
                <span>
                  <strong>Space:</strong>{' '}
                  <span className="text-cyan-400">{codeResult.spaceComplexity}</span>
                </span>
              </div>
              <span className="text-slate-500">Verified</span>
            </div>
          </div>

          {/* Explanation Box */}
          <div
            className={`p-4 rounded-2xl border ${
              darkTheme ? 'bg-[#11182B] border-slate-800' : 'bg-white border-slate-200'
            }`}
          >
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5 flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-blue-400" />
              <span>Logic & Architectural Breakdown</span>
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              {codeResult.explanation}
            </p>

            {/* Best practices */}
            {codeResult.bestPractices?.length > 0 && (
              <div className="mt-3 pt-3 border-t border-slate-800 space-y-1">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                  Best Engineering Practices:
                </span>
                {codeResult.bestPractices.map((bp, i) => (
                  <div key={i} className="text-[11px] text-slate-300">
                    • {bp}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
