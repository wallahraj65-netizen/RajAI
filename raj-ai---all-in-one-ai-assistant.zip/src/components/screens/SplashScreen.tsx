import React, { useEffect, useState } from 'react';
import { Sparkles, ArrowRight, Bot, Cpu } from 'lucide-react';

interface SplashScreenProps {
  onDismiss: () => void;
  darkTheme: boolean;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onDismiss, darkTheme }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(onDismiss, 200);
          return 100;
        }
        return prev + 5;
      });
    }, 45);

    return () => clearInterval(timer);
  }, [onDismiss]);

  return (
    <div
      onClick={onDismiss}
      className={`fixed inset-0 z-50 flex flex-col items-center justify-between p-8 select-none cursor-pointer transition-all duration-500 ${
        darkTheme ? 'bg-[#070B16] text-white' : 'bg-slate-900 text-white'
      }`}
    >
      {/* Top Branding Tag */}
      <div className="pt-6 flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-purple-400/90">
        <Cpu className="w-4 h-4 text-purple-400" />
        <span>Android 15 Edition • Jetpack Compose</span>
      </div>

      {/* Center Hero Logo & Title */}
      <div className="flex flex-col items-center text-center max-w-xs">
        <div className="relative mb-6">
          <div className="absolute -inset-4 bg-gradient-to-r from-purple-600 to-cyan-500 rounded-3xl blur-xl opacity-60 animate-pulse" />
          <div className="relative w-28 h-28 rounded-3xl bg-gradient-to-tr from-purple-700 via-indigo-600 to-cyan-400 p-[3px] shadow-2xl">
            <div className="w-full h-full bg-[#090D1A] rounded-[22px] flex flex-col items-center justify-center p-3">
              <Bot className="w-12 h-12 text-purple-400" />
              <div className="mt-1 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-cyan-400" />
                <span className="text-[10px] font-black tracking-widest bg-gradient-to-r from-purple-400 to-cyan-300 bg-clip-text text-transparent">
                  AI CORE
                </span>
              </div>
            </div>
          </div>
        </div>

        <h1 className="text-4xl font-extrabold tracking-tight bg-gradient-to-r from-white via-slate-100 to-purple-200 bg-clip-text text-transparent">
          Raj AI
        </h1>
        <p className="mt-2 text-sm text-slate-400 font-medium leading-relaxed">
          Your Intelligent All-in-One Android Companion for Chat, Stories, Coding, Study & Creation.
        </p>
      </div>

      {/* Bottom Loading Indicator */}
      <div className="w-full max-w-xs pb-6 flex flex-col items-center gap-3">
        <div className="w-full bg-slate-800/80 rounded-full h-1.5 overflow-hidden border border-slate-700/50">
          <div
            className="h-full bg-gradient-to-r from-purple-500 via-indigo-500 to-cyan-400 transition-all duration-100 rounded-full"
            style={{ width: `${progress}%` }}
          />
        </div>

        <div className="w-full flex items-center justify-between text-[11px] text-slate-400 font-medium">
          <span>Initializing MVVM & Room...</span>
          <span className="text-purple-400 font-bold">{progress}%</span>
        </div>

        <button
          onClick={onDismiss}
          className="mt-2 flex items-center gap-1.5 text-xs text-purple-400 hover:text-purple-300 font-semibold transition-colors"
        >
          <span>Tap anywhere to launch</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
