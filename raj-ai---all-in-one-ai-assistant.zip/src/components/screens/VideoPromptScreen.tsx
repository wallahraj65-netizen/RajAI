import React, { useState } from 'react';
import {
  Video,
  Sparkles,
  Copy,
  Check,
  Camera,
  Sun,
  Music,
  Sliders,
  Layers,
} from 'lucide-react';
import { VideoPromptOutput } from '../../types';
import { api } from '../../services/api';

interface VideoPromptScreenProps {
  darkTheme: boolean;
}

export const VideoPromptScreen: React.FC<VideoPromptScreenProps> = ({
  darkTheme,
}) => {
  const [concept, setConcept] = useState(
    'A cyberpunk street food chef in Old Delhi crafting glowing spiced dumplings under heavy neon rain'
  );
  const [style, setStyle] = useState('Cinematic');
  const [targetTool, setTargetTool] = useState('Google Veo / Sora / Runway Gen-3');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<VideoPromptOutput | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const styles = [
    'Cinematic',
    '3D Animation',
    'Cartoon / Anime',
    'Gaming Unreal Engine 5',
    'Photorealistic 8K',
  ];

  const handleGenerate = async () => {
    if (!concept.trim()) return;
    setLoading(true);
    try {
      const res = await api.generateVideoPrompts({
        concept,
        style,
        targetTool,
      });
      setResult(res);
    } catch (err: any) {
      alert('Failed to generate video prompts: ' + (err.message || 'Error'));
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      {/* Header */}
      <div
        className={`p-4 rounded-3xl border shadow-lg ${
          darkTheme
            ? 'bg-gradient-to-r from-cyan-950/40 via-[#15233D] to-[#111A2E] border-cyan-800/30'
            : 'bg-gradient-to-r from-cyan-50 to-blue-50 border-cyan-200'
        }`}
      >
        <div className="flex items-center gap-2 text-cyan-400 font-bold text-xs uppercase tracking-wider">
          <Video className="w-4 h-4" />
          <span>Cinematography & Prompt Director</span>
        </div>
        <h2 className="text-xl font-black mt-1">AI Video Prompt Studio</h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Detailed camera movements, lighting, and sound prompts for Veo, Sora & Runway.
        </p>
      </div>

      {/* Inputs */}
      <div
        className={`p-4 rounded-3xl border space-y-3.5 shadow-md ${
          darkTheme ? 'bg-[#11182B] border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div>
          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Video Scene Concept / Story Hook
          </label>
          <textarea
            value={concept}
            onChange={(e) => setConcept(e.target.value)}
            rows={2}
            placeholder="Describe what happens in your video..."
            className={`w-full px-3 py-2 rounded-2xl text-xs resize-none border focus:outline-none ${
              darkTheme
                ? 'bg-slate-900 border-slate-700 text-white'
                : 'bg-slate-50 border-slate-300 text-slate-900'
            }`}
          />
        </div>

        {/* Style Selection */}
        <div>
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Director Style
          </label>
          <div className="flex flex-wrap gap-1.5">
            {styles.map((st) => (
              <button
                key={st}
                onClick={() => setStyle(st)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  style === st
                    ? 'bg-cyan-600 text-white font-bold'
                    : darkTheme
                    ? 'bg-slate-800/80 hover:bg-slate-700 text-slate-300'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        {/* Target Video Tool */}
        <div>
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Target AI Video Tool
          </label>
          <select
            value={targetTool}
            onChange={(e) => setTargetTool(e.target.value)}
            className={`w-full px-3 py-2 rounded-xl text-xs font-semibold border focus:outline-none ${
              darkTheme
                ? 'bg-slate-900 border-slate-700 text-white'
                : 'bg-slate-50 border-slate-300 text-slate-900'
            }`}
          >
            <option value="Google Veo / Sora / Runway Gen-3">Google Veo & OpenAI Sora</option>
            <option value="Runway Gen-3 Alpha">Runway Gen-3 Alpha</option>
            <option value="Luma Dream Machine">Luma Dream Machine</option>
            <option value="Kling AI">Kling AI 1.5</option>
            <option value="Pika Labs">Pika 2.0</option>
          </select>
        </div>

        {/* Button */}
        <button
          onClick={handleGenerate}
          disabled={loading || !concept.trim()}
          className="w-full py-3 rounded-2xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-cyan-600/30 transition-all cursor-pointer disabled:opacity-60"
        >
          {loading ? (
            <>
              <span className="w-3 h-3 rounded-full border-2 border-white border-t-transparent animate-spin" />
              <span>Architecting Video Sequences & Camera Shots...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              <span>Generate Multi-Scene Video Prompts</span>
            </>
          )}
        </button>
      </div>

      {/* Results */}
      {result && (
        <div className="space-y-4 pb-8 animate-in fade-in duration-200">
          {/* Master Prompt */}
          <div
            className={`p-4 rounded-3xl border shadow-xl ${
              darkTheme ? 'bg-[#131B2E] border-slate-800' : 'bg-white border-slate-200'
            }`}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-800/60">
              <span className="text-xs font-bold text-cyan-400">Master Video Prompt</span>
              <button
                onClick={() => handleCopy(result.masterPrompt, 'master')}
                className="flex items-center gap-1 text-[11px] font-semibold text-cyan-400 hover:text-white"
              >
                {copiedKey === 'master' ? (
                  <>
                    <Check className="w-3 h-3 text-emerald-400" />
                    <span className="text-emerald-400">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" />
                    <span>Copy Master Prompt</span>
                  </>
                )}
              </button>
            </div>
            <p className="mt-2 text-xs font-mono text-slate-200 leading-relaxed bg-slate-900/80 p-3 rounded-xl border border-slate-800">
              {result.masterPrompt}
            </p>

            {result.negativePrompt && (
              <div className="mt-3 text-[11px] text-slate-400">
                <span className="text-red-400 font-bold">Negative Prompt:</span>{' '}
                {result.negativePrompt}
              </div>
            )}
          </div>

          {/* Individual Scenes */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Shot-by-Shot Prompts
            </h4>

            {result.scenes.map((sc, i) => (
              <div
                key={i}
                className={`p-4 rounded-2xl border ${
                  darkTheme ? 'bg-[#0E1528] border-slate-800' : 'bg-white border-slate-200'
                }`}
              >
                <div className="flex items-center justify-between pb-2 border-b border-slate-800/50">
                  <span className="text-xs font-bold text-cyan-400">
                    Shot {sc.scene} • {sc.timecode}
                  </span>
                  <button
                    onClick={() => handleCopy(sc.promptText, `scene_${sc.scene}`)}
                    className="flex items-center gap-1 text-[11px] text-cyan-400 hover:text-white"
                  >
                    {copiedKey === `scene_${sc.scene}` ? (
                      <Check className="w-3 h-3 text-emerald-400" />
                    ) : (
                      <Copy className="w-3 h-3" />
                    )}
                    <span>Copy Shot Prompt</span>
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 mt-2 text-[11px]">
                  <div className="flex items-center gap-1.5 text-slate-300">
                    <Camera className="w-3.5 h-3.5 text-cyan-400" />
                    <span>{sc.shotType}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-300">
                    <Sun className="w-3.5 h-3.5 text-amber-400" />
                    <span className="truncate">{sc.lighting}</span>
                  </div>
                </div>

                <p className="mt-2 text-xs text-slate-300 bg-slate-900/60 p-2.5 rounded-xl border border-slate-800 font-mono">
                  {sc.promptText}
                </p>

                {sc.audioAmbience && (
                  <div className="mt-2 flex items-center gap-1.5 text-[10px] text-slate-400">
                    <Music className="w-3 h-3 text-purple-400" />
                    <span>
                      <strong>Audio Cue:</strong> {sc.audioAmbience}
                    </span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
