import React, { useState } from 'react';
import {
  Image as ImageIcon,
  Sparkles,
  Download,
  Copy,
  Check,
  Maximize2,
  Ratio,
  Palette,
  AlertCircle,
} from 'lucide-react';
import { ImageOutput } from '../../types';
import { api } from '../../services/api';

interface ImageScreenProps {
  darkTheme: boolean;
}

export const ImageScreen: React.FC<ImageScreenProps> = ({ darkTheme }) => {
  const [prompt, setPrompt] = useState(
    'A majestic royal Bengal tiger with luminescent golden cosmic fur standing on high Himalayan peak, stars in sky'
  );
  const [aspectRatio, setAspectRatio] = useState<'1:1' | '16:9' | '9:16'>('1:1');
  const [style, setStyle] = useState('Cinematic');
  const [loading, setLoading] = useState(false);
  const [imageResult, setImageResult] = useState<ImageOutput | null>(null);
  const [copied, setCopied] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const styleOptions = [
    { id: 'Cinematic', label: '🎬 Cinematic' },
    { id: 'Anime', label: '🌸 Anime Studio' },
    { id: '3D Render', label: '🧊 3D Octane' },
    { id: 'Cyberpunk', label: '⚡ Cyberpunk' },
    { id: 'Photorealistic', label: '📸 Photoreal 8K' },
    { id: 'Oil Painting', label: '🎨 Oil Canvas' },
  ];

  const aspectRatios: { id: '1:1' | '16:9' | '9:16'; label: string; desc: string }[] = [
    { id: '1:1', label: '1:1', desc: 'Square (Feed)' },
    { id: '16:9', label: '16:9', desc: 'Landscape (YouTube)' },
    { id: '9:16', label: '9:16', desc: 'Portrait (Shorts/Reels)' },
  ];

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    setErrorMessage(null);

    try {
      const res = await api.generateImage({
        prompt,
        aspectRatio,
        style,
      });
      setImageResult(res);
    } catch (err: any) {
      setErrorMessage(
        err.message || 'Image generation failed. Please try a different prompt or aspect ratio.'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = () => {
    if (!imageResult) return;
    
    // If it's an SVG data URI, render to canvas for crisp PNG download
    if (imageResult.imageUrl.startsWith('data:image/svg+xml')) {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width || 1200;
        canvas.height = img.height || 1200;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0);
          const pngUrl = canvas.toDataURL('image/png');
          const a = document.createElement('a');
          a.href = pngUrl;
          a.download = `RajAI-Artwork-${Date.now()}.png`;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
        }
      };
      img.src = imageResult.imageUrl;
    } else {
      const a = document.createElement('a');
      a.href = imageResult.imageUrl;
      a.download = `RajAI-Artwork-${Date.now()}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  };

  const handleCopyPrompt = () => {
    if (!imageResult) return;
    navigator.clipboard.writeText(imageResult.prompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      {/* Title Card */}
      <div
        className={`p-4 rounded-3xl border shadow-lg ${
          darkTheme
            ? 'bg-gradient-to-r from-pink-950/40 via-[#18152B] to-[#12172A] border-pink-800/30'
            : 'bg-gradient-to-r from-pink-50 to-rose-50 border-pink-200'
        }`}
      >
        <div className="flex items-center gap-2 text-pink-400 font-bold text-xs uppercase tracking-wider">
          <ImageIcon className="w-4 h-4" />
          <span>Generative AI Art Studio</span>
        </div>
        <h2 className="text-xl font-black mt-1">AI Image Generator</h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Generate illustrations, wallpapers & YouTube thumbnails in custom aspect ratios.
        </p>
      </div>

      {/* Input Controls */}
      <div
        className={`p-4 rounded-3xl border space-y-3.5 shadow-md ${
          darkTheme ? 'bg-[#11182B] border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        {/* Prompt Input */}
        <div>
          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
            Describe Your Image Concept
          </label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            rows={3}
            placeholder="e.g. Futuristic Indian cyberpunk warrior with neon katana in rain..."
            className={`w-full px-3 py-2.5 rounded-2xl text-xs resize-none border focus:outline-none leading-relaxed ${
              darkTheme
                ? 'bg-slate-900 border-slate-700 text-white'
                : 'bg-slate-50 border-slate-300 text-slate-900'
            }`}
          />
        </div>

        {/* Aspect Ratio Selector */}
        <div>
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5 flex items-center gap-1">
            <Ratio className="w-3 h-3 text-pink-400" />
            <span>Aspect Ratio</span>
          </label>
          <div className="grid grid-cols-3 gap-2">
            {aspectRatios.map((ar) => (
              <button
                key={ar.id}
                onClick={() => setAspectRatio(ar.id)}
                className={`py-2 px-2 rounded-xl text-center border transition-all cursor-pointer ${
                  aspectRatio === ar.id
                    ? 'bg-pink-600 border-pink-500 text-white font-bold shadow-md shadow-pink-600/20'
                    : darkTheme
                    ? 'bg-slate-800/80 hover:bg-slate-700 border-slate-700 text-slate-300'
                    : 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700'
                }`}
              >
                <div className="text-xs font-bold">{ar.label}</div>
                <div className="text-[9px] opacity-80 mt-0.5">{ar.desc}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Style Selection */}
        <div>
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5 flex items-center gap-1">
            <Palette className="w-3 h-3 text-pink-400" />
            <span>Visual Art Style</span>
          </label>
          <div className="flex flex-wrap gap-1.5">
            {styleOptions.map((st) => (
              <button
                key={st.id}
                onClick={() => setStyle(st.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  style === st.id
                    ? 'bg-pink-600 text-white font-bold'
                    : darkTheme
                    ? 'bg-slate-800/80 hover:bg-slate-700 text-slate-300'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {st.label}
              </button>
            ))}
          </div>
        </div>

        {/* Generate Button */}
        <button
          onClick={handleGenerate}
          disabled={loading || !prompt.trim()}
          className="w-full py-3 rounded-2xl bg-gradient-to-r from-pink-600 via-rose-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-pink-600/30 transition-all cursor-pointer disabled:opacity-60"
        >
          {loading ? (
            <>
              <span className="w-3 h-3 rounded-full border-2 border-white border-t-transparent animate-spin" />
              <span>Synthesizing High-Resolution Visuals...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              <span>Generate Image ({aspectRatio})</span>
            </>
          )}
        </button>
      </div>

      {/* Error Message */}
      {errorMessage && (
        <div className="p-3.5 rounded-2xl bg-red-950/40 border border-red-500/40 text-red-200 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Generated Image Result Card */}
      {imageResult && (
        <div
          className={`p-4 rounded-3xl border shadow-xl space-y-3 animate-in fade-in duration-200 ${
            darkTheme ? 'bg-[#131B2E] border-slate-800' : 'bg-white border-slate-200'
          }`}
        >
          <div className="flex items-center justify-between pb-2 border-b border-slate-800/60">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-xs font-bold text-pink-400">Generated Art</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
                {imageResult.aspectRatio} • {imageResult.style}
              </span>
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                {imageResult.isDemo ? 'Raj AI Creative Engine' : 'Gemini 3.1'}
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={handleCopyPrompt}
                className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                title="Copy Prompt"
              >
                {copied ? (
                  <Check className="w-4 h-4 text-emerald-400" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </button>
              <button
                onClick={handleDownload}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-pink-600 hover:bg-pink-500 text-white text-xs font-bold cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Save</span>
              </button>
            </div>
          </div>

          {/* Visual Container */}
          <div
            className={`w-full overflow-hidden rounded-2xl bg-black/40 flex items-center justify-center border border-slate-800 ${
              imageResult.aspectRatio === '16:9'
                ? 'aspect-video'
                : imageResult.aspectRatio === '9:16'
                ? 'aspect-[9/16] max-w-[280px] mx-auto'
                : 'aspect-square'
            }`}
          >
            <img
              src={imageResult.imageUrl}
              alt={imageResult.prompt}
              className="w-full h-full object-contain rounded-xl select-none"
            />
          </div>

          <p className="text-[11px] text-slate-400 leading-tight">
            <strong>Prompt:</strong> {imageResult.prompt}
          </p>
        </div>
      )}
    </div>
  );
};
