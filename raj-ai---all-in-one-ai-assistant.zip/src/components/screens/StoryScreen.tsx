import React, { useState } from 'react';
import {
  BookOpen,
  Sparkles,
  Copy,
  Check,
  Share2,
  Film,
  MessageCircle,
  Clock,
  Layers,
  ChevronDown,
} from 'lucide-react';
import { StoryOutput } from '../../types';
import { api } from '../../services/api';

interface StoryScreenProps {
  darkTheme: boolean;
  selectedLanguage: 'English' | 'Hindi' | 'Hinglish';
}

export const StoryScreen: React.FC<StoryScreenProps> = ({
  darkTheme,
  selectedLanguage,
}) => {
  const [genre, setGenre] = useState('horror');
  const [length, setLength] = useState('medium');
  const [storyLanguage, setStoryLanguage] = useState<'Hindi' | 'English' | 'Hinglish'>(
    selectedLanguage
  );
  const [characters, setCharacters] = useState('Aarav and Rohit');
  const [premise, setPremise] = useState(
    'Two childhood friends explore an ancient abandoned haveli during an unexpected storm.'
  );
  const [loading, setLoading] = useState(false);
  const [storyResult, setStoryResult] = useState<StoryOutput | null>(null);
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  const genres = [
    { id: 'horror', label: 'Horror / Ghost 👻' },
    { id: 'comedy', label: 'Comedy / Humour 😂' },
    { id: 'emotional', label: 'Emotional / Drama 🥺' },
    { id: 'cartoon', label: 'Cartoon / Kids 🐰' },
    { id: 'moral', label: 'Moral / Wisdom 🌟' },
    { id: 'mythological', label: 'Mythology / Epic 🏹' },
    { id: 'scifi', label: 'Sci-Fi / Space 🚀' },
  ];

  const handleGenerate = async () => {
    setLoading(true);
    try {
      const res = await api.generateStory({
        genre,
        language: storyLanguage,
        length,
        characters,
        premise,
      });
      setStoryResult(res);
    } catch (err: any) {
      alert('Failed to generate story: ' + (err.message || 'Unknown error'));
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = (text: string, sectionKey: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(sectionKey);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const handleShare = (story: StoryOutput) => {
    const textToShare = `📖 *${story.title}*\n_${story.logline}_\n\n${story.fullStory}\n\n*Moral:* ${story.moral}\n\nGenerated with Raj AI`;
    if (navigator.share) {
      navigator.share({ title: story.title, text: textToShare }).catch(() => {});
    } else {
      navigator.clipboard.writeText(textToShare);
      alert('Full story copied to clipboard!');
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      {/* Title Card */}
      <div
        className={`p-4 rounded-3xl border shadow-lg ${
          darkTheme
            ? 'bg-gradient-to-r from-amber-950/40 via-[#161B2E] to-[#12172A] border-amber-800/30'
            : 'bg-gradient-to-r from-amber-50 to-orange-50 border-amber-200'
        }`}
      >
        <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider">
          <BookOpen className="w-4 h-4" />
          <span>Screenplay & Story Generator</span>
        </div>
        <h2 className="text-xl font-black mt-1">AI Story Studio</h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Generate complete screenplays with scene-by-scene dialogue & AI video prompts.
        </p>
      </div>

      {/* Input Form Controls */}
      <div
        className={`p-4 rounded-3xl border space-y-3 shadow-md ${
          darkTheme ? 'bg-[#11182B] border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        {/* Genre Selection Chips */}
        <div>
          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
            Select Story Genre
          </label>
          <div className="flex flex-wrap gap-1.5">
            {genres.map((g) => (
              <button
                key={g.id}
                onClick={() => setGenre(g.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  genre === g.id
                    ? 'bg-gradient-to-r from-amber-500 to-orange-600 text-white shadow-md shadow-orange-500/20'
                    : darkTheme
                    ? 'bg-slate-800/80 hover:bg-slate-700 text-slate-300'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {g.label}
              </button>
            ))}
          </div>
        </div>

        {/* Story Configuration Row: Language & Length */}
        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
              Language
            </label>
            <select
              value={storyLanguage}
              onChange={(e) => setStoryLanguage(e.target.value as any)}
              className={`w-full px-3 py-2 rounded-xl text-xs font-semibold border focus:outline-none ${
                darkTheme
                  ? 'bg-slate-900 border-slate-700 text-white'
                  : 'bg-slate-50 border-slate-300 text-slate-900'
              }`}
            >
              <option value="Hindi">Hindi (हिंदी)</option>
              <option value="English">English</option>
              <option value="Hinglish">Hinglish</option>
            </select>
          </div>

          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
              Script Length
            </label>
            <select
              value={length}
              onChange={(e) => setLength(e.target.value)}
              className={`w-full px-3 py-2 rounded-xl text-xs font-semibold border focus:outline-none ${
                darkTheme
                  ? 'bg-slate-900 border-slate-700 text-white'
                  : 'bg-slate-50 border-slate-300 text-slate-900'
              }`}
            >
              <option value="short">Short (1-2 scenes)</option>
              <option value="medium">Medium (3-4 scenes)</option>
              <option value="long">Long (5+ scenes)</option>
            </select>
          </div>
        </div>

        {/* Characters Field */}
        <div>
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Character Names & Roles
          </label>
          <input
            type="text"
            value={characters}
            onChange={(e) => setCharacters(e.target.value)}
            placeholder="e.g. Vikram (Brave Explorer), Maya (Archaeologist)"
            className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none ${
              darkTheme
                ? 'bg-slate-900 border-slate-700 text-white'
                : 'bg-slate-50 border-slate-300 text-slate-900'
            }`}
          />
        </div>

        {/* Story Idea / Premise */}
        <div>
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Story Premise / Plot Twist Idea
          </label>
          <textarea
            value={premise}
            onChange={(e) => setPremise(e.target.value)}
            rows={2}
            placeholder="What should happen in the story? Any specific suspense or moral?"
            className={`w-full px-3 py-2 rounded-xl text-xs resize-none border focus:outline-none ${
              darkTheme
                ? 'bg-slate-900 border-slate-700 text-white'
                : 'bg-slate-50 border-slate-300 text-slate-900'
            }`}
          />
        </div>

        {/* Submit Button */}
        <button
          onClick={handleGenerate}
          disabled={loading}
          className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-orange-500/25 transition-all cursor-pointer disabled:opacity-60"
        >
          {loading ? (
            <>
              <span className="w-3 h-3 rounded-full border-2 border-white border-t-transparent animate-spin" />
              <span>Weaving Script & Video Prompts...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              <span>Generate Scene Script & Video Prompts</span>
            </>
          )}
        </button>
      </div>

      {/* Generated Story Display */}
      {storyResult && (
        <div className="space-y-4 pb-8 animate-in fade-in duration-200">
          {/* Header Card */}
          <div
            className={`p-4 rounded-3xl border shadow-lg ${
              darkTheme ? 'bg-[#131B2E] border-slate-800' : 'bg-white border-slate-200'
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  {genre.toUpperCase()}
                </span>
                <h3 className="text-lg font-black mt-2 text-white">{storyResult.title}</h3>
                <p className="text-xs text-slate-400 italic mt-0.5 font-serif">
                  "{storyResult.logline}"
                </p>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  onClick={() => handleCopy(storyResult.fullStory, 'fullStory')}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                  title="Copy Full Story"
                >
                  {copiedSection === 'fullStory' ? (
                    <Check className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
                <button
                  onClick={() => handleShare(storyResult)}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                  title="Share Story"
                >
                  <Share2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Prose Story Paragraphs */}
            <div className="mt-4 pt-4 border-t border-slate-800/60 text-xs leading-relaxed whitespace-pre-wrap text-slate-200 font-sans">
              {storyResult.fullStory}
            </div>

            {storyResult.moral && (
              <div className="mt-3 p-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300 flex items-center gap-2">
                <Sparkles className="w-4 h-4 shrink-0 text-amber-400" />
                <span>
                  <strong>Moral:</strong> {storyResult.moral}
                </span>
              </div>
            )}
          </div>

          {/* Scene-by-Scene Screenplay & AI Video Prompts */}
          {storyResult.scenes && storyResult.scenes.length > 0 && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Film className="w-3.5 h-3.5 text-amber-400" />
                <span>Scene-by-Scene Script & AI Video Prompts</span>
              </h4>

              {storyResult.scenes.map((scene, idx) => (
                <div
                  key={idx}
                  className={`p-4 rounded-2xl border ${
                    darkTheme
                      ? 'bg-[#0E1528] border-slate-800/80'
                      : 'bg-white border-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800/50">
                    <span className="font-bold text-xs text-amber-400">
                      Scene {scene.sceneNumber}: {scene.title}
                    </span>
                    <span className="text-[10px] text-slate-400">{scene.setting}</span>
                  </div>

                  {/* Character Dialogues */}
                  <div className="mt-3 space-y-2">
                    {scene.dialogues.map((dlg, dIdx) => (
                      <div
                        key={dIdx}
                        className="text-xs flex items-baseline gap-2 bg-slate-900/60 p-2 rounded-xl border border-slate-800/60"
                      >
                        <span className="font-bold text-amber-300 shrink-0">
                          {dlg.character}:
                        </span>
                        <span className="text-slate-200 font-sans">"{dlg.line}"</span>
                      </div>
                    ))}
                  </div>

                  {/* AI Video Prompt Card */}
                  <div className="mt-3 p-3 rounded-xl bg-purple-950/30 border border-purple-500/30">
                    <div className="flex items-center justify-between text-[10px] text-purple-300 font-semibold mb-1">
                      <span className="flex items-center gap-1">
                        <Film className="w-3 h-3" />
                        <span>AI Video Prompt (Veo / Runway / Sora)</span>
                      </span>
                      <button
                        onClick={() =>
                          handleCopy(scene.visualPrompt, `vp_${scene.sceneNumber}`)
                        }
                        className="flex items-center gap-1 text-purple-400 hover:text-white"
                      >
                        {copiedSection === `vp_${scene.sceneNumber}` ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-400" />
                            <span className="text-emerald-400">Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>Copy Prompt</span>
                          </>
                        )}
                      </button>
                    </div>
                    <p className="text-[11px] text-slate-300 font-mono leading-tight">
                      {scene.visualPrompt}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
