import React, { useState } from 'react';
import {
  Settings as SettingsIcon,
  Moon,
  Sun,
  Globe,
  Smartphone,
  Cpu,
  Trash2,
  Shield,
  FileText,
  MessageSquare,
  Info,
  LogOut,
  Heart,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';
import { UserPreferences } from '../../types';

interface SettingsScreenProps {
  preferences: UserPreferences;
  onUpdatePreferences: (updated: Partial<UserPreferences>) => void;
  onClearHistory: () => void;
  darkTheme: boolean;
  hasApiKey: boolean;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  preferences,
  onUpdatePreferences,
  onClearHistory,
  darkTheme,
  hasApiKey,
}) => {
  const [modalContent, setModalContent] = useState<{
    title: string;
    body: string;
  } | null>(null);

  const [feedbackSent, setFeedbackSent] = useState(false);
  const [feedbackText, setFeedbackText] = useState('');

  const handleSendFeedback = () => {
    if (!feedbackText.trim()) return;
    setFeedbackSent(true);
    setTimeout(() => {
      setFeedbackSent(false);
      setFeedbackText('');
      alert('Thank you for your feedback! It helps improve Raj AI.');
    }, 1200);
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      {/* Header */}
      <div
        className={`p-4 rounded-3xl border shadow-lg ${
          darkTheme
            ? 'bg-gradient-to-r from-slate-900 via-[#151B2E] to-[#101524] border-slate-800'
            : 'bg-gradient-to-r from-slate-100 to-purple-50 border-slate-200'
        }`}
      >
        <div className="flex items-center gap-2 text-purple-400 font-bold text-xs uppercase tracking-wider">
          <SettingsIcon className="w-4 h-4" />
          <span>App Preferences & System</span>
        </div>
        <h2 className="text-xl font-black mt-1">Settings</h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Customize themes, AI engines, language models, and device simulator options.
        </p>
      </div>

      {/* Group 1: Appearance & Device Mode */}
      <div
        className={`p-4 rounded-3xl border space-y-3.5 shadow-md ${
          darkTheme ? 'bg-[#11182B] border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
          Appearance & Display
        </h3>

        {/* Theme Toggle */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-purple-600/20 text-purple-400">
              {preferences.theme === 'dark' ? (
                <Moon className="w-4 h-4" />
              ) : (
                <Sun className="w-4 h-4" />
              )}
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">App Theme</h4>
              <p className="text-[10px] text-slate-400">Deep Navy Dark Mode / Light Mode</p>
            </div>
          </div>

          <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => onUpdatePreferences({ theme: 'dark' })}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                preferences.theme === 'dark'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Dark
            </button>
            <button
              onClick={() => onUpdatePreferences({ theme: 'light' })}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                preferences.theme === 'light'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Light
            </button>
          </div>
        </div>

        {/* Device Frame Simulator Toggle */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-800/60">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-600/20 text-cyan-400">
              <Smartphone className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">Android Device Frame</h4>
              <p className="text-[10px] text-slate-400">Show flagship mobile bezel & status bar</p>
            </div>
          </div>

          <input
            type="checkbox"
            checked={preferences.deviceFrame}
            onChange={(e) => onUpdatePreferences({ deviceFrame: e.target.checked })}
            className="w-5 h-5 accent-purple-600 rounded cursor-pointer"
          />
        </div>
      </div>

      {/* Group 2: AI Engine & Language */}
      <div
        className={`p-4 rounded-3xl border space-y-3.5 shadow-md ${
          darkTheme ? 'bg-[#11182B] border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
          AI Model & Localization
        </h3>

        {/* Primary Language */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-600/20 text-indigo-400">
              <Globe className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">Default Assistant Language</h4>
              <p className="text-[10px] text-slate-400">Hindi, English, Hinglish</p>
            </div>
          </div>

          <select
            value={preferences.language}
            onChange={(e) => onUpdatePreferences({ language: e.target.value as any })}
            className="px-2.5 py-1 text-xs font-semibold rounded-xl bg-slate-900 border border-slate-800 text-slate-200 focus:outline-none"
          >
            <option value="English">English</option>
            <option value="Hindi">Hindi (हिंदी)</option>
            <option value="Hinglish">Hinglish</option>
          </select>
        </div>

        {/* Connected AI Model Status */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-800/60">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-600/20 text-emerald-400">
              <Cpu className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">AI Engine Architecture</h4>
              <p className="text-[10px] text-slate-400">
                {hasApiKey ? 'Gemini 3.8 Flash (Active)' : 'Demo Engine Simulation (Offline)'}
              </p>
            </div>
          </div>

          <span
            className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
              hasApiKey
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
            }`}
          >
            {hasApiKey ? 'LIVE' : 'DEMO'}
          </span>
        </div>
      </div>

      {/* Group 3: Storage & Data Management */}
      <div
        className={`p-4 rounded-3xl border space-y-3 shadow-md ${
          darkTheme ? 'bg-[#11182B] border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
          Data & Local Storage
        </h3>

        <div className="flex items-center justify-between">
          <div>
            <h4 className="text-xs font-bold text-white">Purge Conversation History</h4>
            <p className="text-[10px] text-slate-400">Clears all locally cached Room SQLite tables</p>
          </div>

          <button
            onClick={() => {
              if (confirm('Clear all conversation history? This cannot be undone.')) {
                onClearHistory();
                alert('All chat and creation history has been purged.');
              }
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-600/20 hover:bg-red-600/30 text-red-400 text-xs font-bold border border-red-500/30 cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear History</span>
          </button>
        </div>
      </div>

      {/* Group 4: Feedback */}
      <div
        className={`p-4 rounded-3xl border space-y-2.5 shadow-md ${
          darkTheme ? 'bg-[#11182B] border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
          <MessageSquare className="w-3.5 h-3.5 text-purple-400" />
          <span>Feedback & Feature Requests</span>
        </h3>
        <textarea
          value={feedbackText}
          onChange={(e) => setFeedbackText(e.target.value)}
          rows={2}
          placeholder="Tell us what new features or improvements you'd like in Raj AI..."
          className={`w-full p-2.5 rounded-xl text-xs resize-none border focus:outline-none ${
            darkTheme
              ? 'bg-slate-900 border-slate-800 text-white'
              : 'bg-slate-50 border-slate-300 text-slate-900'
          }`}
        />
        <button
          onClick={handleSendFeedback}
          disabled={feedbackSent || !feedbackText.trim()}
          className="w-full py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold cursor-pointer disabled:opacity-50"
        >
          {feedbackSent ? 'Submitting...' : 'Submit Feedback'}
        </button>
      </div>

      {/* Group 5: About & Legal */}
      <div
        className={`p-4 rounded-3xl border space-y-2 shadow-md ${
          darkTheme ? 'bg-[#11182B] border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
          About & Legal
        </h3>

        <button
          onClick={() =>
            setModalContent({
              title: 'About Raj AI',
              body: `Raj AI is a comprehensive, production-grade Android and Web AI Assistant engineered with Kotlin, Jetpack Compose, Material 3, and Gemini 3.8 Flash.

Version: 2.5.0 (Build 2026.10)
Architect: Senior Android & AI Systems Engineer
Target Platform: Android 8.0+ (API 26 to API 35)
Database: Local Room SQLite
Network: Secure Retrofit + OkHttp with streaming SSE

Built to empower students, creators, developers, and writers with instant intelligence in Hindi, English, and Hinglish.`,
            })
          }
          className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-slate-800/60 text-xs text-slate-200 cursor-pointer"
        >
          <div className="flex items-center gap-2">
            <Info className="w-4 h-4 text-purple-400" />
            <span>About Raj AI</span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-500" />
        </button>

        <button
          onClick={() =>
            setModalContent({
              title: 'Privacy Policy',
              body: `Privacy Policy for Raj AI:
1. Zero Private Data Harvesting: Raj AI does not sell, market, or transmit your conversations to unauthorized third parties.
2. Local Storage: Conversation logs are stored locally on your device via Room SQLite / Local Storage.
3. Server Processing: AI prompts are securely processed via HTTPS through server-side proxy routes. No API secrets are exposed to client APKs.
4. User Control: You have complete sovereignty to export your history or delete all logs at any time.`,
            })
          }
          className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-slate-800/60 text-xs text-slate-200 cursor-pointer"
        >
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-emerald-400" />
            <span>Privacy Policy</span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-500" />
        </button>

        <button
          onClick={() =>
            setModalContent({
              title: 'Terms of Use',
              body: `Terms of Use for Raj AI:
1. Permitted Use: Raj AI is designed for academic learning, creative storytelling, coding assistance, and content creator ideation.
2. Content Safety: Users must not generate harmful, unlawful, or discriminatory content.
3. Disclaimer: AI responses are generated algorithmically. Users should verify technical, legal, and academic claims independently.`,
            })
          }
          className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-slate-800/60 text-xs text-slate-200 cursor-pointer"
        >
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-cyan-400" />
            <span>Terms of Service</span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-500" />
        </button>
      </div>

      {/* Modal for About/Privacy/Terms */}
      {modalContent && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className={`w-full max-w-sm rounded-3xl p-5 border shadow-2xl space-y-3 ${
              darkTheme ? 'bg-[#0E1528] border-slate-800 text-white' : 'bg-white text-slate-900'
            }`}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-extrabold text-sm">{modalContent.title}</h3>
              <button
                onClick={() => setModalContent(null)}
                className="text-xs text-slate-400 hover:text-white"
              >
                ✕ Close
              </button>
            </div>
            <div className="text-xs leading-relaxed text-slate-300 whitespace-pre-wrap max-h-72 overflow-y-auto pr-1">
              {modalContent.body}
            </div>
            <button
              onClick={() => setModalContent(null)}
              className="w-full py-2 rounded-xl bg-purple-600 text-white text-xs font-bold cursor-pointer"
            >
              Understood
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
